<template>
  <view class="content-list">
    <view class="goods-item" v-for="(item, key) in goods" :key="key">
      <image :src="item.goods_url"></image>
      <view class="goods-item-content">
        <view class="goods-title text-line-hide">{{item.name}}</view>
        <view class="goods-little-title gary-font text-line-hide">限时兑换 | 到店领取</view>
        <view>
          <cmd-progress :percent="(item.sale_count/(item.sale_count+item.remain_count))*100" type="line"
            stroke-color="linear-gradient(to right, #FF66CC, #FF3300)">
          </cmd-progress>
        </view>
        <view class="goods-amount">
          <text space="emsp">{{item.goods_price}}积分</text>
        </view>
        <view class="goods-label" @click="detail(item, $event)">
          <button type="warn" size="mini">立即兑换</button>
        </view>
      </view>
    </view>
  </view>
</template>

<script>
  import cmdProgress from "@/components/cmd-progress/cmd-progress.vue"
  export default {
    components: {
      cmdProgress
    },
    name: "MkGoodsList",
    props: {
      goods: {
        type: Array,
        default: []
      },
    },
    methods: {
      detail(item, e) {
        this.$emit("clickItem", item, e);
      }
    },
  }
</script>

<style lang="scss">
  .content-list {
    background-color: #f9f9f9;
    width: 100%;
    margin: 0 19rpx;
    display: flex;
    flex-wrap: wrap;
  }

  .goods-item {
    background-color: #ffffff;
    width: 347.5rpx;
    border-radius: 19rpx;
    margin: 0 19rpx 19rpx 0;
  }

  .goods-item image {
    margin: 2rpx 23rpx;
    display: flex;
    justify-content: center;
    align-items: center;
    width: 300rpx;
    height: 300rpx;
    border-radius: 19rpx 19rpx 0 0;
  }

  .goods-item-content {
    padding: 19rpx;
  }

  .goods-little-title {
    padding: 10rpx 0;
  }

  .goods-title {
    font-weight: bold;
  }

  .goods-amount {
    display: flex;
    align-items: baseline;
  }

  .goods-amount text {
    color: #ff0000;
  }

  .goods-amount view {
    margin-left: 22rpx;
  }

  .goods-label {
    padding: 10rpx 0 0;
  }

  .gary-font {
    color: #999;
    font-size: 22rpx;
  }

  .text-line-hide {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
</style>
