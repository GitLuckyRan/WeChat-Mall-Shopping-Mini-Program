// 表单校验规则由 schema2code 生成，不建议直接修改校验规则，而建议通过 schema2code 生成, 详情: https://uniapp.dcloud.net.cn/uniCloud/schema


const validator = {
  "orderprice": {
    "rules": [
      {
        "format": "double"
      }
    ],
    "title": "积分价格",
    "label": "积分价格"
  },
  "ordercount": {
    "rules": [
      {
        "format": "int"
      }
    ],
    "title": "商品数量",
    "label": "商品数量"
  },
  "order_date": {
    "rules": [
      {
        "format": "timestamp"
      }
    ],
    "title": "订单时间",
    "label": "订单时间"
  },
  "order_good": {
    "rules": [
      {
        "format": "string"
      }
    ],
    "title": "购买物品",
    "label": "购买物品"
  },
  "order_owner": {
    "rules": [
      {
        "format": "string"
      }
    ],
    "title": "购物者昵称",
    "label": "购物者昵称"
  },
  "order_affirm": {
    "rules": [
      {
        "format": "bool"
      }
    ],
    "title": "是否领取",
    "defaultValue": false,
    "label": "是否领取"
  }
}

const enumConverter = {}

function filterToWhere(filter, command) {
  let where = {}
  for (let field in filter) {
    let { type, value } = filter[field]
    switch (type) {
      case "search":
        if (typeof value === 'string' && value.length) {
          where[field] = new RegExp(value)
        }
        break;
      case "select":
        if (value.length) {
          let selectValue = []
          for (let s of value) {
            selectValue.push(command.eq(s))
          }
          where[field] = command.or(selectValue)
        }
        break;
      case "range":
        if (value.length) {
          let gt = value[0]
          let lt = value[1]
          where[field] = command.and([command.gte(gt), command.lte(lt)])
        }
        break;
      case "date":
        if (value.length) {
          let [s, e] = value
          let startDate = new Date(s)
          let endDate = new Date(e)
          where[field] = command.and([command.gte(startDate), command.lte(endDate)])
        }
        break;
      case "timestamp":
        if (value.length) {
          let [startDate, endDate] = value
          where[field] = command.and([command.gte(startDate), command.lte(endDate)])
        }
        break;
    }
  }
  return where
}

export { validator, enumConverter, filterToWhere }
