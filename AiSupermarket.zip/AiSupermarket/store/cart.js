export default {
  // 为当前模块开启命名空间
  namespaced: true,

  // 模块的 state 数据
  state: () => ({
    // 购物车的数组，用来存储购物车中每个商品的信息对象
    // 每个商品的信息对象，都包含如下 6 个属性：
    // { goods_sn, name, goods_price, goods_count, goods_state，goods_url,goods_limit}
    cart: JSON.parse(uni.getStorageSync('cart') || '[]'),
  }),

  // 模块的 mutations 方法
  mutations: {
    //加入购物车
    addToCart(state, goods) {
      console.log('加入购物车')
      const findResult = state.cart.find(x => x.goods_sn === goods.goods_sn)
      // console.log(findResult)
      if (!findResult) {
        state.cart.push(goods)
      } else {
        if (parseInt(goods.goods_sn.charAt(0)) >= 0 && parseInt(goods.goods_sn.charAt(0)) < 10) {
          console.log('非限购商品')
          findResult.goods_count++
        } else {
          console.log('限购商品')
          uni.showToast({
            title: "限购一件",
            icon: "fail",
          })
          return
        }
      }
      this.commit('m_cart/saveToStorage')
      uni.showToast({
        title: "加入购物车成功~~",
        icon: "success",
      })
      console.log(state.cart)
    },
    saveToStorage(state) {
      uni.setStorageSync('cart', JSON.stringify(state.cart))
    },
    //更新商品的状态
    updataGoodsState(state, goods) {
      const findResult = state.cart.find(x => x.goods_sn === goods.goods_sn)
      if (findResult) {
        findResult.goods_state = goods.goods_state
        this.commit('m_cart/saveToStorage')
      }
    },
    updataGoodsCount(state, goods) {
      const findResult = state.cart.find(x => x.goods_sn === goods.goods_sn)
      if (findResult) {
        findResult.goods_count = goods.goods_count
      }
      this.commit('m_cart/saveToStorage')
    },
    // 从购物车中移除
    removeGoodsById(state, goods) {
      state.cart = state.cart.filter(x => x.goods_sn != goods.goods_sn)
      this.commit('m_cart/saveToStorage')
      console.log("移除成功" + goods)
    },
    //全选全不选按钮
    updataAllGoodsState(state, newState) {
      //遍历并改变商品状态
      state.cart.forEach(x => x.goods_state = newState)
      this.commit('m_cart/saveToStorage')
    },

  },

  // 模块的 getters 属性
  //方法返回的是值
  getters: {
    //购物车中所有商品的数量
    total(state) {
      //reduce() 方法对数组中的每个元素按序执行一个由您提供的 reducer 函数，每一次运行 reducer 会将先前元素的计算结果作为参数传入，最后将其结果汇总为单个返回值
      return state.cart.reduce((total, item) => total += item.goods_count, 0)
    },
    //购物车中已经勾选商品的总数量
    checkedCount(state) {
      return state.cart.filter(x => x.goods_state).reduce((total, item) => total += item.goods_count, 0)
    },
    //选中商品的总价值
    checkedGoodsAmount(state) {
      return state.cart.filter(x => x.goods_state).reduce((total, item) => (total += item.goods_price * item
        .goods_count), 0).toFixed(2)
    },

  }
}
