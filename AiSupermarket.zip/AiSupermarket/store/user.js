export default {
  // 开启命名
  namespaced: true,
  state: () => ({
    address: JSON.parse(uni.getStorageSync('address') || '{}'),
    token: uni.getStorageSync('token') || '',
    //用户信息对象
    userInfo: JSON.parse(uni.getStorageSync('userInfo') || '{}'),
    //重定向obj
    redirectInfo: null,
    userTrack: JSON.parse(uni.getStorageSync('userTrack') || '[]')
  }),
  mutations: {
    // 修改头像
    updateFace(state, face) {
      state.userInfo.avatarUrl = face
      uni.setStorageSync('userInfo', JSON.stringify(state.userInfo))
    },
    // 修改用户名
    updateName(state, name) {
      state.userInfo.nickName = name
      uni.setStorageSync('userInfo', JSON.stringify(state.userInfo))
    },
    addUserTrack(state, goods_category) {
      if (state.userTrack.includes(goods_category)) { //判断是否已经存在该浏览记录
        let pos = state.userTrack.indexOf(goods_category)
        state.userTrack.splice(pos, 1)
        state.userTrack.unshift(goods_category)
      } else {
        state.userTrack.unshift(goods_category)
      }
      const shallCopy = state.userTrack.slice(0, 10)
      state.userTrack = shallCopy
      console.log(shallCopy)
      this.commit('m_user/saveTrackToStorage')
    },
    saveTrackToStorage(state) { //存储到本地中
      uni.setStorageSync('userTrack', JSON.stringify(state.userTrack))
    },
    //用户订单信息
    //更新地址
    updataAdderss(state, address) {
      state.address = address
      this.commit('m_user/saveToStorage')
    },
    saveToStorage(state) {
      uni.setStorageSync('userTrack', JSON.stringify(state.userTrack))
    },
    // 更新用户信息
    updataUserInfo(state, userinfo) {
      state.userInfo = userinfo
      this.commit('m_user/saveUserInfoToStorage')
    },
    saveUserInfoToStorage(state) {
      uni.setStorageSync('userInfo', JSON.stringify(state.userInfo))
    },
    // 更新token信息
    updataToken(state, token) {
      state.token = token
      this.commit('m_user/saveTokenToStorage')
    },
    saveTokenToStorage(state) {
      uni.setStorageSync('token', JSON.stringify(state.token))
    },
    updataRedirectInfo(state, info) {
      state.redirectInfo = info
    }
  },
  getters: {
    //用户地址信息
    addstr(state) {
      if (!state.address.provinceName) return ''
      return state.address.provinceName + state.address.cityName + state.address.countyName + state.address.detailInfo
    }
  }
}
