<template>
  <view class="uni-container">
    <uni-forms ref="form" :model="formData" validateTrigger="bind">
      <uni-forms-item name="feedbackContent" label="反馈内容">
        <uni-easyinput v-model="formData.feedbackContent"></uni-easyinput>
      </uni-forms-item>
      <uni-forms-item name="mobile" label="联系电话">
        <uni-easyinput v-model="formData.mobile"></uni-easyinput>
      </uni-forms-item>
      <uni-forms-item name="isRead" label="是否处理">
        <switch @change="binddata('isRead', $event.detail.value)" :checked="formData.isRead"></switch>
      </uni-forms-item>
      <uni-forms-item label="反馈图片">
        <uni-td align="center" v-model="formData.images" class="image-box">
          <view v-for="(img,i) in formData.images" :key="i" class="image-item">
            <image :src="img+''"></image>
          </view>
        </uni-td>
      </uni-forms-item>
      <view class="uni-button-group">
        <button type="primary" class="uni-button" style="width: 100px;" @click="submit">提交</button>

        <button class="uni-button" style="width: 100px;" @click="back">返回</button>

      </view>
    </uni-forms>
  </view>
</template>

<script>
  import {
    validator
  } from '../../js_sdk/validator/feedback-list.js';

  const db = uniCloud.database();
  const dbCmd = db.command;
  const dbCollectionName = 'feedback-list';

  function getValidator(fields) {
    let result = {}
    for (let key in validator) {
      if (fields.includes(key)) {
        result[key] = validator[key]
      }
    }
    return result
  }



  export default {
    data() {
      let formData = {
        "feedbackContent": "",
        "mobile": "",
        "isRead": false,
        "images": []
      }
      return {

        formData,
        formOptions: {},
        rules: {
          ...getValidator(Object.keys(formData))
        }
      }
    },
    onLoad(e) {
      this.imageSearch(e.id)
      if (e.id) {
        const id = e.id
        this.formDataId = id
        this.getDetail(id)
      }
    },
    onReady() {
      this.$refs.form.setRules(this.rules)
    },
    methods: {

      /**
       * 验证表单并提交
       */
      async imageSearch(id) {
        const search = uniCloud.importObject('feedback')
        const {
          data: res
        } = await search.search(id)
        this.formData.images = []
        for (let i = 0; i < res.length; i++) {
          this.formData.images.push(res[i])
        }
        console.log(this.formData.images)
      },
      submit() {
        uni.showLoading({
          mask: true
        })

        this.$refs.form.validate().then((res) => {
          return this.submitForm(res)
        }).catch(() => {}).finally(() => {
          uni.hideLoading()
        })
        setTimeout(() => uni.navigateBack(), 500)
      },
      back() {
        setTimeout(() => uni.navigateBack(), 500)
      },

      /**
       * 提交表单
       */
      submitForm(value) {
        // 使用 clientDB 提交数据
        return db.collection(dbCollectionName).doc(this.formDataId).update(value).then((res) => {
          uni.showToast({
            title: '修改成功'
          })
          this.getOpenerEventChannel().emit('refreshData')
          setTimeout(() => uni.navigateBack(), 500)
        }).catch((err) => {
          uni.showModal({
            content: err.message || '请求服务失败',
            showCancel: false
          })
        })
      },

      /**
       * 获取表单数据
       * @param {Object} id
       */
      getDetail(id) {
        uni.showLoading({
          mask: true
        })
        db.collection(dbCollectionName).doc(id).field("feedbackContent,mobile,isRead,images").get().then((res) => {
          const data = res.result.data[0]
          if (data) {
            this.formData = data

          }
        }).catch((err) => {
          uni.showModal({
            content: err.message || '请求服务失败',
            showCancel: false
          })
        }).finally(() => {
          uni.hideLoading()
        })
      }
    }
  }
</script>
<style lang="scss">
  .uni-button {
    margin-left: 20px;
  }

  .image-box {
    display: flex;
    justify-content: center;
    align-items: center;
    flex-wrap: nowrap;
    justify-content: space-around;
    height: 300px;

    .image-item {
      image {
        height: 200px;
        width: 200px;
      }
    }

  }
</style>
