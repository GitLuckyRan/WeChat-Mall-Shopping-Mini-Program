<template>
  <view>
    <my-search @click="gotoSeach"></my-search>
    <view class="sroll-view-container">
      <scroll-view class="sroll-view-left" scroll-y="true" :style="{height: wh+'px'}">
        <block v-for="(item,i) in cateList" :key="i">
          <view :class="['scroll-view-left-item' ,i===active?'active':'']" @click="activeChange(i)">
            {{item.category_name}}
          </view>
        </block>
      </scroll-view>
      <scroll-view class="sroll-view-right" scroll-y="true" :style="{height: wh+'px'}" :scroll-top="scrollTop"
        scroll-with-animation="true" @scroll="listenScroll">
        <view class="lev-item" v-for="(item2,i2) in catelevel2" :key="i2">
          <view class="l2-left" @click="levClick(item2)">
            <image :src="item2.goods_url"></image>
          </view>
          <view class="l2-right">
            <view class="l2-title" @click="levClick(item2)">{{item2.name}}</view>
            <view class="l2-left-b">
              <view class="l2-price" @click="levClick(item2)">¥{{item2.goods_price | tofixed}}</view>
              <view class="icon" @click="addCart(item2)">
                <uni-icons type="plus" color="green" size="25"></uni-icons>
              </view>
            </view>
          </view>
        </view>

      </scroll-view>
    </view>
  </view>
</template>

<script>
  import badgeMix from "@/mixins/tabbar-badge.js"
  import {
    mapMutations
  } from 'vuex'
  export default {
    mixins: [badgeMix],
    data() {
      return {
        wh: 0,
        cateList: [],
        active: 0,
        category_name: "茶",
        // 二级分类的列表
        catelevel2: [],
        scrollTop: 0,
        pagenum: 1,
        isloding: false,
        totals: 0,
        leve2: [],
        screenY: 345
      };
    },
    onLoad() {
      const sysInfo = uni.getSystemInfoSync()
      this.wh = sysInfo.windowHeight - 50
      this.getCateList()
    },

    methods: {
      ...mapMutations('m_cart', ['addToCart']),
      lower() {
        console.log('位置' + this.scrollTop)
        if (this.pagenum * 8 >= this.totals) return uni.$showMsg('数据加载完毕！')
        if (this.isloding) return
        // 让页码值自增 +1
        this.pagenum += 1
        const ListInfo = {
          category_id: this.category_name,
          pagenum: this.pagenum
        }
        // 重新获取列表数据
        this.getCateList(ListInfo)
        uni.pageScrollTo({
          scrollTop: this.scrollTop,
          duration: 300
        })
      },
      listenScroll(e) { //监听滚动
        console.log(e.detail)
        if (this.screenY - e.detail.scrollTop < 200) { //监听滚动到div底部
          this.screenY = this.screenY + 1200
          this.scrollTop = e.detail.scrollTop
          this.lower();
        }

      },
      activeChange(i) {
        this.active = i
        this.category_name = this.cateList[this.active]
        this.pagenum = 1
        this.leve2 = [],
          this.getCateLevel2(this.category_name)
        this.scrollTop = this.scrollTop === 0 ? 1 : 0

      },
      async getCateList() {
        const CateList = uniCloud.importObject('goods_cy')
        const {
          data: res
        } = await CateList.getCategory()
        this.cateList = res
        this.catelevel2 = this.getCateLevel2(this.cateList[this.active])
      },
      async getCateLevel2(category_name) {
        this.isloding = true
        const Catelevel2 = uniCloud.importObject('goods_cy')
        const ListInfo = {
          category_id: category_name.category_name,
          pagenum: this.pagenum
        }
        console.log(ListInfo)
        const {
          data: res
        } = await Catelevel2.getCategoryList(ListInfo)
        const res1 = await Catelevel2.getCategoryList(ListInfo)
        this.isloding = false
        this.totals = res1.total
        console.log(res)
        this.leve2 = [...this.leve2, ...res]
        this.catelevel2 = []
        this.catelevel2 = this.leve2

      },
      levClick(item2) {
        uni.navigateTo({
          url: '/subpkg/goods_details/goods_details?goods_sn=' + item2.goods_sn
        })
      },
      gotoSeach() {
        uni.navigateTo({
          url: "/subpkg/search/search"
        })
      },
      addCart(goods_details) {
        let flag = false
        if (parseInt(goods_details.goods_sn.charAt(0)) >= 0 && parseInt(goods_details.goods_sn.charAt(0)) < 10) {
          flag = false
        } else {
          flag = true
        }
        const goods = {
          goods_sn: goods_details.goods_sn, // 商品的Id
          name: goods_details.name, // 商品的名称
          goods_price: goods_details.goods_price, // 商品的价格
          goods_count: 1, // 商品的数量
          goods_small_logo: goods_details.goods_url, // 商品的图片
          goods_state: true, // 商品的勾选状态
          goods_limit: flag
        }
        this.addToCart(goods)
      },
    },
    filters: {
      tofixed(num) {
        return Number(num).toFixed(2)
      }
    }
  }
</script>

<style lang="scss">
  .sroll-view-container {
    display: flex;

    .sroll-view-left {
      width: 150px;
    }

    .scroll-view-left-item {
      background-color: #f7f7f7;
      line-height: 60px;
      text-align: center;
      font-size: 12px;

      &.active {
        background-color: #ffffff;
        position: relative;

        &::before {
          content: '';
          display: block;
          width: 3px;
          height: 30px;
          background-color: #C00000;
          position: absolute;
          top: 50%;
          left: 0;
          // 实现元素垂直居中效果
          transform: translateY(-50%);
        }
      }
    }
  }

  .sroll-view-right {
    margin: 3px 3px;

    .lev-item {
      height: 200rpx;
      width: 260px;
      display: flex;
      justify-content: space-between;
      margin: 5px 2px;
      border-bottom: 1px #efefef solid;

      .l2-left {
        display: flex;
        justify-content: center;
        align-items: center;
        width: 100px;
        height: 100px;

        image {
          width: 90px;
          height: 90px;
          border-radius: 5px;
        }
      }

      .l2-right {
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        padding-top: 5px;
        width: 150px;
        height: 100px;

        .l2-title {
          width: 150px;
          font-size: 13px;
          font-weight: 550;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          letter-spacing: 0.7px;
        }

        .l2-left-b {
          display: flex;
          justify-content: space-between;
          padding-bottom: 5px;

          .icon {
            margin: 2px, 2px;
          }

          .l2-price {
            color: #C00000;
            font-size: 14px;
            font-weight: 600;
          }
        }

      }
    }
  }
</style>
