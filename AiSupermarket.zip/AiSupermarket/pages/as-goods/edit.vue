<template>
  <view class="uni-container">
    <uni-forms ref="form" :model="formData" validateTrigger="bind">
      <uni-forms-item name="goods_price" label="商品价格" required>
        <uni-easyinput type="number" v-model="formData.goods_price"></uni-easyinput>
      </uni-forms-item>
      <uni-forms-item name="category_id" label="商品类别">
        <uni-data-picker v-model="formData.category_id" collection="goods-categories" field="name as value,name as text"></uni-data-picker>
      </uni-forms-item>
      <uni-forms-item name="goods_sn" label="货号" required>
        <uni-easyinput placeholder="商品的唯一货号" v-model="formData.goods_sn" trim="both"></uni-easyinput>
      </uni-forms-item>
      <uni-forms-item name="name" label="名称" required>
        <uni-easyinput placeholder="商品名称" v-model="formData.name" trim="both"></uni-easyinput>
      </uni-forms-item>
      <uni-forms-item name="keywords" label="关键字">
        <uni-easyinput placeholder="商品关键字，为搜索引擎收录使用" v-model="formData.keywords" trim="both"></uni-easyinput>
      </uni-forms-item>
      <uni-forms-item name="goods_location" label="商品位置">
        <uni-easyinput v-model="formData.goods_location" trim="both"></uni-easyinput>
      </uni-forms-item>
      <uni-forms-item name="goods_url" label="图像">
        <uni-file-picker return-type="object" v-model="formData.goods_url"></uni-file-picker>
      </uni-forms-item>
      <uni-forms-item name="remain_count" label="库存数量">
        <uni-easyinput placeholder="库存数量" type="number" v-model="formData.remain_count"></uni-easyinput>
      </uni-forms-item>
      <uni-forms-item name="sale_count" label="">
        <uni-easyinput placeholder="已售数量" type="number" v-model="formData.sale_count"></uni-easyinput>
      </uni-forms-item>
      <uni-forms-item name="is_on_sale" label="是否上架">
        <switch @change="binddata('is_on_sale', $event.detail.value)" :checked="formData.is_on_sale"></switch>
      </uni-forms-item>
      <uni-forms-item name="is_best" label="是否精品">
        <switch @change="binddata('is_best', $event.detail.value)" :checked="formData.is_best"></switch>
      </uni-forms-item>
      <uni-forms-item name="is_new" label="是否新品">
        <switch @change="binddata('is_new', $event.detail.value)" :checked="formData.is_new"></switch>
      </uni-forms-item>
      <uni-forms-item name="is_hot" label="是否热销">
        <switch @change="binddata('is_hot', $event.detail.value)" :checked="formData.is_hot"></switch>
      </uni-forms-item>
      <uni-forms-item name="goods_date" label="生产日期">
        <uni-datetime-picker return-type="timestamp" v-model="formData.goods_date"></uni-datetime-picker>
      </uni-forms-item>
      <uni-forms-item name="expiration_date" label="保质日期">
        <uni-datetime-picker return-type="timestamp" v-model="formData.expiration_date"></uni-datetime-picker>
      </uni-forms-item>
      <view class="uni-button-group">
        <button type="primary" class="uni-button" style="width: 100px;" @click="submit">提交</button>
        <navigator open-type="navigateBack" style="margin-left: 15px;">
          <button class="uni-button" style="width: 100px;">返回</button>
        </navigator>
      </view>
    </uni-forms>
  </view>
</template>

<script>
  import { validator } from '../../js_sdk/validator/as-goods.js';

  const db = uniCloud.database();
  const dbCmd = db.command;
  const dbCollectionName = 'as-goods';

  function getValidator(fields) {
    let result = {}
    for (let key in validator) {
      if (fields.includes(key)) {
        result[key] = validator[key]
      }
    }
    return result
  }

  

  export default {
    data() {
      let formData = {
        "goods_price": null,
        "category_id": "",
        "goods_sn": "",
        "name": "",
        "keywords": "",
        "goods_location": "",
        "goods_url": null,
        "remain_count": null,
        "sale_count": 0,
        "is_on_sale": null,
        "is_best": null,
        "is_new": null,
        "is_hot": null,
        "goods_date": null,
        "expiration_date": null
      }
      return {
        formData,
        formOptions: {},
        rules: {
          ...getValidator(Object.keys(formData))
        }
      }
    },
    onLoad(e) {
      if (e.id) {
        const id = e.id
        this.formDataId = id
        this.getDetail(id)
      }
    },
    onReady() {
      this.$refs.form.setRules(this.rules)
    },
    methods: {
      
      /**
       * 验证表单并提交
       */
      submit() {
        uni.showLoading({
          mask: true
        })
        this.$refs.form.validate().then((res) => {
          return this.submitForm(res)
        }).catch(() => {
        }).finally(() => {
          uni.hideLoading()
        })
      },

      /**
       * 提交表单
       */
      submitForm(value) {
        // 使用 clientDB 提交数据
        return db.collection(dbCollectionName).doc(this.formDataId).update(value).then((res) => {
          uni.showToast({
            title: '修改成功'
          })
          this.getOpenerEventChannel().emit('refreshData')
          setTimeout(() => uni.navigateBack(), 500)
        }).catch((err) => {
          uni.showModal({
            content: err.message || '请求服务失败',
            showCancel: false
          })
        })
      },

      /**
       * 获取表单数据
       * @param {Object} id
       */
      getDetail(id) {
        uni.showLoading({
          mask: true
        })
        db.collection(dbCollectionName).doc(id).field("goods_price,category_id,goods_sn,name,keywords,goods_location,goods_url,remain_count,sale_count,is_on_sale,is_best,is_new,is_hot,goods_date,expiration_date").get().then((res) => {
          const data = res.result.data[0]
          if (data) {
            this.formData = data
            
          }
        }).catch((err) => {
          uni.showModal({
            content: err.message || '请求服务失败',
            showCancel: false
          })
        }).finally(() => {
          uni.hideLoading()
        })
      }
    }
  }
</script>
