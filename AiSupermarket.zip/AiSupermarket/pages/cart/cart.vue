<template>
  <view v-if="cart.length!==0">
    <view class="address-box">
      <view class="children-box">
        <my-address></my-address>
      </view>
    </view>
    <!-- 购物车图标 -->
    <view class="cart-title">
      <uni-icons type="shop" size="18" color="red"></uni-icons>
      <text class="cart-title-text">购物车</text>
    </view>
    <view class="cart-info">
      <uni-swipe-action>
        <block class="cart-item" v-for="(goods,i) in cart" :key='i'>
          <uni-swipe-action-item :right-options="options" @click="swipeActionClickHandler(goods)">
            <my-goods :goods="goods" :show-radio="true" @radio-chang="radioChangHandler" :show-num="true"
              @num-change="numChangeHandler"></my-goods>
          </uni-swipe-action-item>
        </block>
      </uni-swipe-action>
    </view>
    <view class="cart-container">
      <my-settle></my-settle>
    </view>
  </view>
  <view class="null-box" v-else>
    <image src="/static/cart_box/null-cart.png"></image>
    <text class="null-text">空空如也~~</text>
  </view>
</template>

<script>
  import badgeMix from "@/mixins/tabbar-badge.js"
  import {
    forEach
  } from "lodash";
  import {
    mapMutations,
    mapState,
  } from 'vuex'
  export default {
    mixins: [badgeMix],
    computed: {
      ...mapState('m_cart', ['cart'])
    },
    onLoad() {

    },
    data() {
      return {
        options: [{
          text: '删除',
          style: {
            backgroundColor: '#C00000'
          }
        }],
        carts: []
      };
    },
    methods: {
      ...mapMutations('m_cart', ['updataGoodsState', 'updataGoodsCount', 'removeGoodsById']),
      radioChangHandler(e) {
        this.updataGoodsState(e)
      },
      toDetail(goods) {
        uni.navigateTo({
          url: '/subpkg/goods_details/goods_details?goods_sn=' + goods.goods_sn
        })
      },
      numChangeHandler(e) {
        if (parseInt(e.goods_sn.charAt(0)) >= 0 && parseInt(e.goods_sn.charAt(0)) < 10) {
          this.updataGoodsCount(e)
        } else {
          return
        }
      },
      swipeActionClickHandler(goods) {
        console.log(goods)
        this.removeGoodsById(goods)
      }
    },

  }
</script>

<style lang="scss">
  .cart-container {
    padding-bottom: 50px;
  }

  .address-box {
    background-color: #f9f9f9;
    height: 75px;
    margin-bottom: 5px;


    .children-box {
      background-color: #fff;
      border-radius: 8px;
    }
  }

  .cart-info {
    background-color: #f9f9f9;
  }

  .null-box {
    padding-top: 150px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;

    image {
      height: 100px;
      width: 100px;
    }
  }
</style>
