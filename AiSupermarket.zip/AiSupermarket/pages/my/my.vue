<template>
  <view class="my-login-container">
    <my-login v-if="!token"></my-login>
    <my-userinfo v-else id="info"></my-userinfo>
  </view>
</template>

<script>
  import badgeMix from "@/mixins/tabbar-badge.js"
  import {
    mapState
  } from 'vuex'
  export default {
    computed: {
      ...mapState('m_user', ['token'])
    },
    data() {
      return {};
    },
    methods: {

    },
    onPullDownRefresh() {
      this.compData = this.selectComponent("#info");
      this.compData.data.checkMoney()
      setTimeout(function() {
        uni.stopPullDownRefresh();
      }, 1500);
    },


  }
</script>

<style lang="scss">
  page,
  .my-login-container {
    height: 100%;
  }
</style>
