<template>
  <view class="big-box">
    <view class="search-box">
      <my-search @click="gotoSearch"></my-search>
    </view>
    <!-- 轮播图 -->
    <view class="swiper-container">
      <swiper :indicator-dots="true" :autoplay="true" :interval="3000" :duration="1000">
        <swiper-item v-for="(item,i) in Swiperlist" :key="i" @click="swiperClick(item)">
          <view>
            <image :src="item.icon" mode="heightFix"></image>
          </view>
        </swiper-item>
      </swiper>

    </view>
    <view class="tipss">
      <view class="tipss-item">
        <view>
          <uni-icons type="location-filled" size="10"></uni-icons><text>
            仅限洛阳市区
          </text>
        </view>
        <view><text>满100免运费</text></view>
        <view><text>10KM即时配</text></view>
      </view>
    </view>
    <!-- 导航栏 -->
    <view class="nav-container">
      <navigator class="nav-item" v-for="(item,i) in navList" :key="i" @click="navClick(item)">
        <image :src="item.icon"></image>
        <!-- <text>{{item.nav_name}}</text> -->
      </navigator>
    </view>
    <scroll-view class="scroll-view" scroll-x="true" style="width: 100%; height: 30px;">
      <!-- 这里是字幕内容，通过数据绑定来实现循环滚动 -->
      <view v-for="(item, index) in subtitleList" :key="index" class="subtitle-item">{{item}}</view>
    </scroll-view>
    <view class="limit-box">
      <view>
        <view class="limit-time"><text>每日限时抢购</text>
          <uni-icons type="cart" color="white" size="24"></uni-icons>
        </view>
        <uni-segmented-control :current="current" :values="items" styleType="button" activeColor="#FF3000"
          @clickItem="onClickItem">
        </uni-segmented-control>
        <!-- <view>当前时间{{Hour}}:{{Minutes}}:{{seconds}}</view> -->
        <view class="content">
          <view v-show="current === 0">
            <view v-if="Hour<7" class="wait">
              <image src="../../static/sale/wait.gif"></image>
            </view>
            <view v-else-if="Hour===7||Hour===8">
              <orange-longswiper :list="limitList" :config="limitList" @tapMore="tapMore" @tapList="limittapList"
                @addCart="addCart">
              </orange-longswiper>
            </view>
            <view v-else class="image-box">
              <image src="../../static/sale/true.gif" class="img"></image>
            </view>
          </view>
          <view v-if="current === 1">
            <view v-if="Hour<11" class="wait">
              <image src="../../static/sale/wait.gif"></image>
            </view>
            <view v-else-if="Hour===11||Hour===12">
              <orange-longswiper :list="limitList" :config="limitList" @tapMore="tapMore" @tapList="limittapList"
                @addCart="addCart">
              </orange-longswiper>
            </view>
            <view v-else class="image-box">
              <image src="../../static/sale/true.gif" class="img"></image>
            </view>
          </view>
          <view v-else-if="current === 2">
            <view v-if="Hour<17" class="wait">
              <image src="../../static/sale/wait.gif"></image>
            </view>
            <view v-else-if="Hour===17||Hour===18">
              <orange-longswiper :list="limitList" :config="limitList" @tapMore="tapMore" @tapList="limittapList"
                @addCart="addCart">
              </orange-longswiper>
            </view>
            <view v-else class="image-box">
              <image src="../../static/sale/true.gif" class="img"></image>
            </view>
          </view>
        </view>
      </view>
    </view>
    <!-- 猜你喜欢 -->
    <view class="floor-container">
      <view class="floor-title">猜你喜欢</view>
      <view>
        <orange-longswiper :list="likeList" :config="likeList" @tapMore="tapMore" @tapList="liketapList"
          @addCart="addCart">
        </orange-longswiper>
      </view>
    </view>
    <!-- 精品推荐 -->
    <view class="floor-container">
      <view class="floor-title">精品推荐</view>
      <view>
        <orange-longswiper :list="bestList" :config="bestList" @tapMore="tapMore" @tapList="besttapList"
          @addCart="addCart">
        </orange-longswiper>
      </view>
    </view>
    <!-- 热销产品 -->
    <view class="floor-container">
      <view class="floor-title">热销产品</view>
      <view>
        <orange-longswiper :list="hotList" :config="hotList" @tapMore="tapMore" @tapList="hotapList" @addCart="addCart">
        </orange-longswiper>
      </view>
    </view>
    <view class="floor-container">
      <view class="floor-title">新品上市</view>
      <view>
        <orange-longswiper :list="newList" :config="newList" @tapMore="tapMore" @tapList="newtapList"
          @addCart="addCart">
        </orange-longswiper>
      </view>
    </view>
    <view>
      <view class="tbottom">~~~到底啦~~~</view>
    </view>
  </view>
</template>

<script>
  import badgeMix from "@/mixins/tabbar-badge.js"
  import {
    curry
  } from "lodash";
  import {
    mapMutations,
    mapState
  } from 'vuex'
  export default {
    mixins: [badgeMix],
    computed: {
      ...mapState('m_user', ['userTrack']),
    },
    onShow() {
      this.getLikeList()
    },
    watch: {
      Hour() {
        this.checkTime()
      },
      LikeList() {
        this.getLikeList()
      },
      userTrack() {
        this.getLikeList()
      }
    },
    onPullDownRefresh() {
      this.getLikeList()
    },
    data() {
      return {
        Swiperlist: [],
        likeList: [],
        navList: [],
        hotList: [],
        newList: [],
        bestList: [],
        limitList: [],
        items: ['7点-9点', '11点-13点', '17点-19点'],
        current: 0,
        Hour: 0,
        Minutes: 0,
        seconds: 0,
        time: '',
        subtitleList: ['仅限洛阳市区内购买'], // 字幕列表
        timer: null // 定时器
      };
    },
    onPullDownRefresh() {
      this.getLikeList()
    },
    mounted() {
      // 开始定时器，每隔1秒向左滚动一格
      this.timer = setInterval(() => {
        this.subtitleList.push(this.subtitleList.shift())
      }, 1000)
    },
    beforeDestroy() {
      // 销毁定时器
      clearInterval(this.timer)
    },
    onLoad() {
      this.getSwiperList()
      this.getBestList()
      this.getLikeList()
      this.getNavList()
      this.getHotList()
      this.getNewList()
      this.getTime()
      this.checkTime()
    },
    methods: {
      ...mapMutations('m_cart', ['addToCart']),
      ...mapMutations('m_user', ['addUserTrack']),
      onClickItem(e) {
        if (this.current != e.currentIndex) {
          this.current = e.currentIndex;
        }
      },
      getTime() {
        this.timer = setInterval(() => { //定时获取当前时间
          this.Hour = new Date().getHours()
        }, 1000);
      },
      checkTime() {
        if (this.Hour >= 7 && this.Hour < 9) {
          this.current = 0
          this.time = 'morning'
        } else if (this.Hour >= 11 && this.Hour < 13) {
          this.current = 1
          this.time = 'afternoon'
        } else if (this.Hour >= 17 && this.Hour < 19) {
          this.current = 2
          this.time = 'night'
        } else {
          this.time = 'other'
          this.current = this.current
        }
        this.getLimitList(this.time)
      },
      async getLikeList() {
        const LikeList = uniCloud.importObject('like-goods')
        let limitUserTrack = this.userTrack.slice(0, 10)
        if (limitUserTrack.length == 0) {
          limitUserTrack = ['新鲜水果', '肉蛋家禽', '牛奶酸奶']
        }
        const {
          data: res
        } = await LikeList.getLike(limitUserTrack)
        for (let i = 0; res[i] != null; i++) {
          for (let j = 0; res[i][j] != null; j++) {
            if (!this.likeList.includes(res[i][j])) {
              this.likeList.push(res[i][j])
            }
          }
        }
        this.likeList = this.likeList.slice(0, 6)
      },
      async getSwiperList() {
        const swiperList = uniCloud.importObject('swiper-list')
        const {
          data: res
        } = await swiperList.get()
        this.Swiperlist = res
      },
      async getNavList() {
        const navList = uniCloud.importObject('goods-nav')
        const {
          data: res
        } = await navList.get()
        this.navList = res
      },
      async getHotList() {
        const hotList = uniCloud.importObject('hot-goods')
        const {
          data: res
        } = await hotList.getHot()
        this.hotList = res
        if (this.likeList.length = 0) {
          this.likeList = res
        }
      },
      async getNewList() {
        const newList = uniCloud.importObject('hot-goods')
        const {
          data: res
        } = await newList.getNew()
        this.newList = res
      },
      async getBestList() {
        const bestList = uniCloud.importObject('hot-goods')
        const {
          data: res
        } = await bestList.getBest()
        this.bestList = res
      },
      async getLimitList(time) {
        const bestList = uniCloud.importObject('limit-goods')
        const {
          data: res
        } = await bestList.getLimitGoods(time)
        this.limitList = res
      },
      async swiperClick(item) {

        uni.navigateTo({
          url: '/subpkg/goods_list/goods_list?category_id=' + item.category
        })

      },
      liketapList(e) {
        const goods_sn = this.likeList[e.index].goods_sn
        uni.navigateTo({
          url: "/subpkg/goods_details/goods_details?goods_sn=" + goods_sn
        })
      },
      limittapList(e) {
        const goods_sn = this.limitList[e.index].goods_sn
        uni.navigateTo({
          url: "/subpkg/goods_details/goods_details?goods_sn=" + goods_sn
        })
      },
      hotapList(e) {
        const goods_sn = this.hotList[e.index].goods_sn
        uni.navigateTo({
          url: "/subpkg/goods_details/goods_details?goods_sn=" + goods_sn
        })
      },
      newtapList(e) {
        const goods_sn = this.newList[e.index].goods_sn
        uni.navigateTo({
          url: "/subpkg/goods_details/goods_details?goods_sn=" + goods_sn
        })
      },
      besttapList(e) {
        const goods_sn = this.bestList[e.index].goods_sn
        uni.navigateTo({
          url: "/subpkg/goods_details/goods_details?goods_sn=" + goods_sn
        })
      },
      addCart(goods_details) {
        let flag = false
        if (parseInt(goods_details.goods_sn.charAt(0)) >= 0 && parseInt(goods_details.goods_sn.charAt(0)) < 10) {
          flag = false
        } else {
          flag = true
        }
        const goods = {
          goods_sn: goods_details.goods_sn, // 商品的Id
          name: goods_details.name, // 商品的名称
          goods_price: goods_details.goods_price, // 商品的价格
          goods_count: 1, // 商品的数量
          goods_small_logo: goods_details.goods_url, // 商品的图片
          goods_state: true, // 商品的勾选状态
          goods_limit: flag
        }
        this.addToCart(goods)
      },
      navClick(item) {
        uni.navigateTo({
          url: '/subpkg/goods_list/goods_list?category_id=' + item.nav_name
        })
      },
      moreClick() {
        uni.switchTab({
          url: "/pages/classify/classify"
        })
      },
      gotoSearch() {
        uni.navigateTo({
          url: "/subpkg/search/search"
        })
      }
    }
  }
</script>

<style lang="scss">
  .scroll-view {
    white-space: nowrap;
    /* 设置子元素不换行 */
    overflow: hidden;
    /* 隐藏超出容器宽度的子元素 */
    padding-left: 100%;
    /* 在容器左侧添加一个等于容器宽度的padding，使子元素能够开始向左滚动 */
    animation: scroll 10s linear infinite;
    align-items: center;

    /* 使用CSS动画来实现滚动效果 */
    .subtitle-item {
      display: flex;
      justify-content: center;
      align-items: center;
    }
  }

  @keyframes scroll {
    0% {
      transform: translateX(0);
      /* 初始位置 */
    }

    100% {
      transform: translateX(-100%);
      /* 结束位置 */
    }
  }

  .search-box {
    border-radius: 5px;
    //设置吸顶效果
    position: sticky;
    //设置吸顶位置
    top: 0px;
    //设置层级防止被覆盖，防止轮播图被覆盖
    z-index: 999;
    margin: 0 5px;
  }

  .limit-box {
    background-color: #ffffff;
    border-radius: 5px;
  }

  .big-box {
    background-color: #f9f9f9;
    margin: 0 5px;
  }

  .tipss {
    height: 15px;
    margin: 2.5px 2.5px;
    background-color: #f9f9f9;
    border-radius: 3px;

    .tipss-item {
      background-color: #ffffff;
      display: flex;
      justify-content: space-around;
      font-size: 13px;
      color: #696969;
      font-weight: 550;
    }
  }

  .limit-time {
    display: flex;
    align-items: center;
    background-color: #ff3000;
    height: 30px;
    border-top-left-radius: 5px;
    border-top-right-radius: 5px;

    text {
      margin-left: 5px;
      margin-right: 3px;
      color: white;
      font-size: 19px;
      font-weight: 600;
      margin-bottom: 4px;
    }
  }

  .content {
    height: 200px;

    .image-box {
      display: flex;
      justify-content: center;
      align-items: center;

      .img {
        height: 190px;
        width: 190px;
      }
    }
  }

  .wait {
    display: flex;
    justify-content: center;
    align-items: center;

    image {
      height: 150px;
      width: 240px;
    }

  }

  .swiper-container {
    position: sticky;
    height: 170px;
    background-color: #ffffff;
    border-radius: 5px;

    swiper-item {
      margin: 5px 10px;

      image {
        border-radius: 5px;
        height: 160px;
      }
    }
  }

  .scroll-view {
    height: 50rpx;
    width: 100%;
    background-color: #f5f5f5;
  }

  .nav-container {

    display: flex;
    justify-content: space-around;
    background-color: #ffffff;
    flex-wrap: wrap;
    margin: 5px 2px;

    .nav-item {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      margin: 5px 5px;

      image {
        width: 150rpx;
        height: 200rpx;
      }
    }
  }

  .floor-container {
    display: flex;
    flex-direction: column;
    height: 220px;
    margin: 5px 5px;
    background-color: #ffffff;
    border-radius: 5px;

    .floor-title {
      margin: 5px 6px;
      font-weight: bold;

    }
  }

  .tbottom {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 30px;
    font-size: 15px;
    color: gray;
  }

  .search-box {
    //设置吸顶效果
    position: sticky;
    //设置吸顶位置
    top: 0;
    //设置层级防止被覆盖，防止轮播图被覆盖
    z-index: 999;
  }
</style>
