<template>
  <view class="goods-detail-container" v-if="goods_details.name!==null">
    <view v-for="(item,i) in goods_details" :key="i" class="big-container">
      <view class="img-box">
        <image :src="item.goods_url"></image>
      </view>
      <view class="item-container">
        <view class="item-name">商品名称：{{item.name}}</view>
      </view>
      <view class="item-remaim">
        <view><text class="yunfei">运费</text><text> 满100免运费</text></view>
        <view class="remain-count">剩余 {{item.remainCount}}</view>
      </view>


      <view class="item-details">
        <view class="item-details-x">商品价格：¥{{item.goods_price | tofixed}}</view>
        <view class="item-details-x">商品位置：{{item.goods_location}}</view>
        <view class="item-details-x">生产日期：{{item.goods_date | formatDate('-')}}</view>
        <view class="item-details-x">过期日期：{{item.expiration_date | formatDate('-')}}</view>
      </view>
    </view>

    <!-- 商品导航组件 -->
    <view class="goods_nav">
      <!-- fill 控制右侧按钮的样式 -->
      <!-- options 左侧按钮的配置项 -->
      <!-- buttonGroup 右侧按钮的配置项 -->
      <!-- click 左侧按钮的点击事件处理函数 -->
      <!-- buttonClick 右侧按钮的点击事件处理函数 -->
      <uni-goods-nav :fill="true" :options="options" :buttonGroup="buttonGroup" @click="onClick"
        @buttonClick="buttonClick" />
    </view>
  </view>
  </view>
</template>

<script>
  import {
    mapMutations,
    mapState,
    mapGetters
  } from 'vuex'
  export default {

    computed: {
      ...mapState('m_cart', ['cart']),
      ...mapGetters('m_cart', ['total']),
      ...mapState('m_user', ['userTrack'])
    },
    data() {
      return {
        goods_details: {},
        options: [{
          icon: 'headphones',
          text: '客服'
        }, {
          icon: 'cart',
          text: '购物车',
          info: 2
        }],
        buttonGroup: [{
            text: '加入购物车',
            backgroundColor: '#ff0000',
            color: '#fff'
          },
          // {
          //   text: '立即购买',
          //   backgroundColor: '#ffa200',
          //   color: '#fff'
          // }
        ]
      };
    },
    onLoad(options) {
      console.log(options)
      const goods_sn = options.goods_sn
      this.getGoodsDetails(goods_sn)
    },
    watch: {

      total: {
        handler(newVal) {
          const findResult = this.options.find((x) => x.text === '购物车')
          if (findResult) {
            findResult.info = newVal
          }
        },
        // immediate 属性用来声明此侦听器，是否在页面初次加载完毕后立即调用
        immediate: true
      }
    },
    methods: {
      ...mapMutations('m_cart', ['addToCart']),
      ...mapMutations('m_user', ['addUserTrack']),
      async getGoodsDetails(goods_sn) {
        const goodsDetail = uniCloud.importObject('goods_cy')
        const {
          data: res
        } = await goodsDetail.getGoodsDetails(goods_sn)
        this.goods_details = res
        this.addUserTrack(res[0].category_id)
      },
      onClick(e) {
        if (e.content.text == "购物车") {
          uni.switchTab({
            url: '/pages/cart/cart'
          })
        } else {
          uni.showToast({
            title: "请拨打电话1000",
            icon: "none",
            duration: 2500
          })
        }
      },
      buttonClick(e) {
        if (e.content.text == "加入购物车") {
          let flag = false
          if (parseInt(this.goods_details[0].goods_sn.charAt(0)) >= 0 && parseInt(this.goods_details[0].goods_sn.charAt(
              0)) < 10) {
            flag = false
          } else {
            flag = true
          }
          const goods = {
            goods_sn: this.goods_details[0].goods_sn, // 商品的Id
            name: this.goods_details[0].name, // 商品的名称
            goods_price: this.goods_details[0].goods_price, // 商品的价格
            goods_count: 1, // 商品的数量
            goods_small_logo: this.goods_details[0].goods_url, // 商品的图片
            goods_state: true, // 商品的勾选状态
            goods_limit: flag
          }
          this.addToCart(goods)
        }
      },

    },
    filters: {
      // 时间戳处理
      formatDate: function(value, spe = '/') {
        let data = new Date(value);
        let year = data.getFullYear();
        let month = data.getMonth() + 1;
        let day = data.getDate();
        month = month > 10 ? month : "0" + month;
        day = day > 10 ? day : "0" + day;
        return `${year}${spe}${month}${spe}${day}`;
      },
      tofixed(num) {
        return Number(num).toFixed(2)
      }
    }
  }
</script>

<style lang="scss">
  /* CDN 服务仅供平台体验和调试使用，平台不承诺服务的稳定性，企业客户需下载字体包自行发布使用并做好备份。 */
  @font-face {
    font-family: "Ali";
    font-weight: 700;
    src: url("//at.alicdn.com/wf/webfont/Uk0JQipPUADW/S4NttqdVuj61OR6BmjViz.woff2") format("woff2"),
      url("//at.alicdn.com/wf/webfont/Uk0JQipPUADW/ZmEfVVU2gcvOIj80NAKg7.woff") format("woff");
    font-display: swap;
  }

  .goods-detail-container {
    background-color: #f9f9f9;
  }

  .item-remaim {
    display: flex;
    justify-content: space-between;
    background-color: #ffffff;
    color: darkgray;
    font-size: 15px;
    margin-bottom: 5px;
    height: 30px;
    align-items: center;
    border-radius: 5px;
    font-weight: bolder;
    border-radius: 5px;

    .yunfei {
      color: black;
      margin-right: 20px;
    }

    .remain-count {
      margin-right: 2px;
    }
  }

  .big-container {
    display: flex;
    flex-direction: column;
    height: 40%;

    .img-box {
      background-color: #ffffff;
      display: flex;
      justify-content: center;
      align-items: center;
      border-radius: 5px;

      image {
        width: 374px;
        height: 374px;
        border-radius: 10px;
        margin: 5px 5px;
      }


    }

    .item-container {
      background-color: #ffffff;
      display: flex;
      justify-content: center;
      height: 50px;
      align-items: center;
      margin-bottom: 8px;
      border-radius: 5px;

      .item-name {
        font-size: 15px;
        font-weight: bolder;
        letter-spacing: 0.5;
        margin: 5px 2px;
        height: 30px;
      }
    }


    .item-details {
      background-color: #ffffff;
      height: 40%;

      .item-details-x {
        align-items: center;
        line-height: 25px;
        font-family: "Ali";
        font-size: 14px;
        font-weight: bold;
        margin: 5px 2px;
      }
    }
  }

  .goods-nav {
    width: 100%;
    position: fixed;
    bottom: 0rpx;
    left: 0rpx;
  }
</style>
