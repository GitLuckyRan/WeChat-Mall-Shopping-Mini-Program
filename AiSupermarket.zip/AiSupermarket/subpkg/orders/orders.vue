<template>
  <view class="goodsList-container">

    <view class="goods-item" v-for="(item,i) in orderDetails" :key="i">
      <view class="goods-items">
        <view class="l-left" @click="goodsListClick(item)">
          <image :src="item.order_url"></image>
        </view>
        <view class="details" @click="goodsListClick(item)">
          <view class="item-details">商品名称：{{item.order_name}}</view>
          <view class="item-details">商品价格：¥{{item.orderprice| tofixed}}</view>
          <view class="item-details">购买数量：{{item.ordercount}}</view>
          <view class="item-details">订单编号：{{item.orderList}}</view>
          <view class="item-details">订单日期：{{item.orderList/1000 | formatDate('-')}}</view>
          <!-- <view class="item-details">生产日期：{{item.order_date | formatDate('-')}}</view>
          <view class="item-details">过期时间：{{item.order_expiration | formatDate('-')}}</view> -->
        </view>
      </view>
      <view v-if="!item.order_affirm" class="order_affirm">
        <view><button type="primary" size="mini" @click="affirm(item.orderList)"> 签收</button></view>
        <view><button type="default" size="mini" @click="cancelffirm(item.orderList)"> 取消订单</button></view>
        <view><button type="warn" size="mini" @click="disaffirm(item.orderList)"> 拒签</button></view>
      </view>
      <view v-if="item.order_affirm" class="affirmSure">已签收</view>
    </view>

  </view>


</template>

<script>
  import {
    mapState,
    mapMutations
  } from 'vuex'
  export default {
    computed: {
      ...mapState('m_user', ['userInfo']),
    },
    data() {
      return {
        pagenum: 1,
        orderList: [],
        orderDetails: [],
        isloding: false,
        totals: 0,
        nowlength: 0
      };
    },
    onLoad() {
      this.getOrderList(1)
    },
    onReachBottom() {
      if (this.pagenum * 8 >= this.totals) return uni.$showMsg('订单加载完毕！')
      if (this.isloading) return
      // 让页码值自增 +1
      this.pagenum += 1
      // 重新获取列表数据
      this.getOrderList(this.pagenum)
    },
    methods: {
      ...mapMutations('m_user', ['updataAdderss']),
      async getOrderList(pagenum) {
        this.isloding = true
        const ordersInfo = {
          nickName: this.userInfo.nickName,
          pagenum: pagenum
        }
        const orders = uniCloud.importObject('all-orders')
        const {
          data: res
        } = await orders.goodsOrder(ordersInfo)
        const res1 = await orders.goodsOrder(ordersInfo)
        console.log(res.data)
        console.log(this.orderList)
        this.isloding = false
        this.totals = res1.total
        this.orderList = [...this.orderList, ...res.data]
        this.getGoodsList(this.orderList)
      },
      cancelffirm() {
        uni.showModal({
          content: '请拨打本店电话：100000',
          title: '提示'
        })
      },
      disaffirm() {
        uni.showModal({
          content: '请前往个人中心页面填写问题反馈！',
          title: '提示'
        })
      },
      async affirm(item) {
        const orders = uniCloud.importObject('goods-order')
        const {
          data: res
        } = await orders.affirm(item)
        console.log(res)
        if (res.updated !== 0) {
          uni.$showMsg("签收成功~")
        } else {
          uni.$showMsg("签收失败~")
        }
      },
      async getGoodsList(orderLists) {
        const orderList = orderLists
        const getGoodsDetails = uniCloud.importObject('goods_cy')
        for (let i = this.nowlength; i < orderList.length; i++) {
          const {
            data: res
          } = await getGoodsDetails.getGoodsDetails(orderList[i].order_good)
          let goodsDetail = {
            orderList: orderList[i].orderList,
            orderprice: orderList[i].orderprice,
            ordercount: orderList[i].ordercount,
            order_good: orderList[i].order_good,
            order_affirm: orderList[i].order_affirm,
            order_name: res[0].name,
            order_url: res[0].goods_url,
            order_date: res[0].goods_date,
            order_expiration: res[0].expiration_date,
            order_location: res[0].goods_location
          }
          this.orderDetails.unshift(goodsDetail)
        }
        this.nowlength = orderList.length
      },
      goodsListClick(item) {
        uni.navigateTo({
          url: '/subpkg/goods_details/goods_details?goods_sn=' + item.order_good
        })
      }
    },
    filters: {
      tofixed(num) {
        return Number(num).toFixed(2)
      },
      formatDate: function(value, spe = '/') {
        let data = new Date(value);
        let year = data.getFullYear();
        let month = data.getMonth() + 1;
        let day = data.getDate();
        let hour = data.getHours()
        let Minutes = data.getMinutes()
        month = month > 10 ? month : "0" + month;
        day = day > 10 ? day : "0" + day;
        hour = hour > 10 ? hour : "0" + hour;
        Minutes = Minutes > 10 ? Minutes : "0" + Minutes;
        return `${year}${spe}${month}${spe}${day} ${hour}:${Minutes}`;
      },
    }
  }
</script>

<style lang="scss">
  .order_affirm {
    display: flex;
    justify-content: space-between;
    margin-left: 120px;
    margin-right: 5px;
  }

  .affirmSure {
    font-size: 18px;
    display: flex;
    justify-content: center;
  }

  .goodsList-container {
    display: flex;
    flex-direction: column;
    padding-top: 1.5px;
    margin: 5px 5px;
    background-color: #f9f9f9;
    border-radius: 2px;

    .goods-item {
      background-color: white;
      height: 180px;
      width: 98%;
      align-items: center;
      margin: 5px 3px;
      border-radius: 5px;

      .goods-items {
        display: flex;
        justify-content: space-between;
        font-size: 15px;
      }

      .l-left {
        width: 105px;
        height: 105px;
        display: flex;
        justify-content: center;
        align-items: center;

        image {
          width: 90px;
          height: 90px;
          border-radius: 5px;
        }
      }

      .l-right {
        height: 95px;
        display: flex;
        flex-direction: column;
        justify-content: space-between;

        .l-title {
          width: 265px;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          font-size: 14px;
          letter-spacing: 1px;
        }

        .l-price {
          color: #C00000;
          font-weight: 600;

        }
      }
    }

    .details {
      background-color: white;
      border-radius: 5px;
      margin-bottom: 8px;

      .item-details {
        height: 25px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin: 0 10px;
        font-size: 14px;
        font-size: 14px;
        letter-spacing: 1px;
      }
    }

  }
</style>
