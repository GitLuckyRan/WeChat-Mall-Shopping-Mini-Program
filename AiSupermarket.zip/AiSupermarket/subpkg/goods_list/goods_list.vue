<template>
  <view class="goodsList-container">
    <!-- 商品列表 -->
    <view class="goods-item" v-for="(item,i) in goodsList" :key="i" @click="goodsListClick(item)">
      <view class="l-left">
        <image :src="item.goods_url"></image>
      </view>
      <view class="l-right">
        <view class="l-title">{{item.name}}</view>
        <view class="l-price">¥{{item.goods_price | tofixed}}</view>
      </view>
    </view>
  </view>
</template>

<script>
  export default {
    data() {
      return {
        goodsList: [],
        pagenum: 1,
        categoryId: '',
        isloding: false,
        total: 0
      };
    },
    onReachBottom() { // 判断是否还有下一页数据
      if (this.pagenum * 8 >= this.total) return uni.$showMsg('数据加载完毕！')
      if (this.isloding) return
      // 让页码值自增 +1
      this.pagenum += 1
      const ListInfo = {
        category_id: this.categoryId,
        pagenum: this.pagenum
      }
      // 重新获取列表数据
      this.getGoodsList(ListInfo)
    },
    onLoad(options) {
      console.log(options)
      this.pagenum = 1
      const category_id = options.category_id
      this.categoryId = category_id
      const ListInfo = {
        category_id: category_id,
        pagenum: this.pagenum
      }
      this.getGoodsList(ListInfo)
    },
    methods: {
      async getGoodsList(ListInfo) {
        this.isloding = true
        const getCategoryList = uniCloud.importObject('goods_cy')
        const {
          data: res
        } = await getCategoryList.getCategoryList(ListInfo)
        const res1 = await getCategoryList.getCategoryList(ListInfo)
        this.isloding = false
        console.log(res1.total)
        this.total = res1.total
        this.goodsList = [...this.goodsList, ...res]
      },
      goodsListClick(item) {
        uni.navigateTo({
          url: '/subpkg/goods_details/goods_details?goods_sn=' + item.goods_sn
        })
      }
    },

    filters: {
      tofixed(num) {
        return Number(num).toFixed(2)
      }
    }
  }
</script>

<style lang="scss">
  .goodsList-container {
    padding-top: 1.5px;
    margin: 5px 5px;
    background-color: #f9f9f9;
    border-radius: 2px;

    .goods-item {
      background-color: white;
      height: 130px;
      width: 98%;
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin: 5px 3px;
      border-radius: 5px;

      .l-left {
        width: 105px;
        height: 105px;
        display: flex;
        justify-content: center;
        align-items: center;

        image {
          width: 90px;
          height: 90px;
          border-radius: 5px;
        }
      }

      .l-right {
        height: 95px;
        display: flex;
        flex-direction: column;
        justify-content: space-between;

        .l-title {
          width: 265px;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          font-size: 14px;
          font-weight: 550;
          letter-spacing: 1px;
        }

        .l-price {
          color: #C00000;
          font-weight: 600;

        }
      }
    }
  }
</style>
