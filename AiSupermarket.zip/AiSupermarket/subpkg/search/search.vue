<template>
  <view>
    <!-- 搜索框 -->
    <view class="search-box">
      <!-- @input	uniSearchBar 的 value 改变时触发事件，返回参数为uniSearchBar的value	e=value -->
      <uni-search-bar @input="input" :radius="100" cancelButton="none" focus="true">
      </uni-search-bar>
    </view>
    <!-- 搜索列表 -->
    <view class="search-list" v-if="search_list.length!==0">
      <view class="search-item" v-for="(item,i) in search_list" :key="i" @click="searchClick(item)">
        <view class="l-left">
          <image :src="item.goods_url"></image>
        </view>
        <view class="l-right">
          <view class="l-title">{{item.name}}</view>
          <view class="l-price">¥{{item.goods_price | tofixed}}</view>
        </view>
      </view>
    </view>
    <!-- 搜索历史记录 -->
    <view class="history-box" v-else>
      <!-- 标题框 -->
      <view class="history-title">
        <view>搜索历史</view>
        <uni-icons type="trash" size="15" @click="clean"></uni-icons>
      </view>
      <!-- 列表区域 -->
      <uni-tag :text="item" v-for="(item,i) in histories" :key="i"
        custom-style="background-color: #efefef; border-color: #efefef; color: #000;" size="normal"
        @click="gotoGoodList(item)"></uni-tag>
    </view>
  </view>
</template>

<script>
  export default {
    data() {
      return {
        timer: null,
        search_list: [],
        key: '',
        historyList: ['a', 'app', 'apple'],
      };
    },
    onLoad() {
      //刚加载是获取搜索记录
      this.historyList = JSON.parse(uni.getStorageSync('key') || '[]')
    },
    methods: {
      input(e) {
        clearTimeout((this.timer)) //清除之前定时器
        this.timer = setTimeout(() => {
          this.key = e //将搜索框的值赋值给key
          this.getSearchList()
        }, 1000)
      },
      async getSearchList() {
        if (this.key.length === 0) {
          this.search_list = []
          return
        }
        const result = uniCloud.importObject('goods-search')
        const {
          data: res
        } = await result.goodsSearch(this.key)
        this.search_list = res
        this.saveHistoryData()
      },
      clean() {
        this.historyList = []
        uni.setStorageSync('key', '[]')
      },
      saveHistoryData() {
        const set = new Set(this.historyList)
        set.delete(this.key) //删除所有相同的搜索记录
        set.add(this.key)
        this.historyList = Array.from(set)
        // 调用 uni.setStorageSync(key, value) 将搜索历史记录持久化存储到本地
        uni.setStorageSync('key', JSON.stringify(this.historyList))
      },
      gotoGoodList(item) {
        uni.navigateTo({
          url: '/subpkg/goods_list/goods_list?category_id=' + item
        })
      },
      searchClick(item) {
        uni.navigateTo({
          url: '/subpkg/goods_details/goods_details?goods_sn=' + item.goods_sn
        })
      }
    },
    computed: {
      histories() {
        return [...this.historyList].reverse()
      }
    },
    filters: {
      tofixed(num) {
        return Number(num).toFixed(2)
      }
    },

  }
</script>

<style lang="scss">
  .search-box {
    position: sticky;
    top: 0;
    z-index: 999;
  }

  .search-list {
    padding-top: 1.5px;
    margin: 5px 5px;
    background-color: #f9f9f9;
    border-radius: 2px;

    .search-item {
      background-color: white;
      height: 130px;
      width: 98%;
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin: 5px 3px;
      border-radius: 5px;


      .l-left {
        width: 105px;
        height: 105px;
        display: flex;
        justify-content: center;
        align-items: center;

        image {
          width: 90px;
          height: 90px;
          border-radius: 5px;
        }
      }

      .l-right {
        height: 95px;
        display: flex;
        flex-direction: column;
        justify-content: space-between;

        .l-title {
          width: 265px;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          font-size: 14px;
          font-weight: 550;
          letter-spacing: 1px;
        }

        .l-price {
          color: #C00000;
          font-weight: 600;

        }
      }
    }
  }

  .history-box {
    padding: 0 5px;

    .history-title {
      display: flex;
      justify-content: space-between;
      height: 30px;
      font-size: 16px;
      font-weight: bold;
      align-items: center;
      padding: 5px 5px;
      margin-bottom: 5px;
    }

    .history-list {
      display: flex;
      flex-wrap: wrap;

      .uni-tag {
        margin-top: 5px;
        margin-right: 5px;
      }
    }
  }
</style>
