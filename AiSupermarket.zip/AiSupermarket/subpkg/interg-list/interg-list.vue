<template>
  <!-- /* goods参数传递商品列表数据     clickItem每个商品点击的触发事件 */ -->
  <mk-goods-list :goods="intergList" @clickItem="goodsItem"></mk-goods-list>
  <!-- /* 点击方法触发后，会回调两个参数，第一个参数当前点击的商品数据，第二个参数是拿到当前点击的$event值 */ -->
</template>
<script>
  import {
    mapState
  } from 'vuex'

  export default {
    computed: {
      ...mapState('m_user', ['userInfo'])
    },
    data() {
      return {
        intergList: []
      };
    },
    onLoad() {
      this.getIntergList()
    },
    methods: {
      async getIntergList() {
        const get = uniCloud.importObject('interg-goods')
        const {
          data: res
        } = await get.getInterg()
        console.log(res)
        this.intergList = res
      },
      async goodsItem(item, e) {
        const intergOrder = {
          role_integral: item.goods_price,
          role_name: this.userInfo.nickName
        }
        const flag = await this.goodCount(item.goods_sn)
        console.log(flag)
        if (!flag) {
          uni.showToast({
            title: "积分商品数量不足！"
          })
          return
        }
        const creatOrder = {
          order_good: item.goods_sn,
          order_owner: this.userInfo.nickName,
          goods_count: 1,
          orderprice: item.goods_price
        }
        this.subCount(item.goods_sn)
        this.TosubInterg(intergOrder)
        this.createIntergalOrder(creatOrder)
        this.getIntergList()
      },
      async subCount(goods_sn) {
        const count = uniCloud.importObject('interg-goods')
        const res = await count.subCount(goods_sn)
      },
      async goodCount(goods_sn) {
        const count = uniCloud.importObject('interg-goods')
        const res = await count.goodCount(goods_sn)
        if (res.errcode == 300) {
          return false
        } else {
          return true
        }
      },
      async TosubInterg(item) {
        const subs = uniCloud.importObject('interg-goods')
        const res = await subs.subInterg(item)
        if (res.errcode == 200) {
          uni.$showMsg("兑换成功~")
        } else {
          uni.$showMsg("兑换失败，请检查积分是否充足！")
        }
      },
      async createIntergalOrder(creatOrder) {
        const create = uniCloud.importObject('intergal-order')
        const res = await create.IntergalOrder(creatOrder)
      }
    },
    filters: {
      tofixed(num) {
        return Number(num).toFixed(2)
      }
    }
  }
</script>

<style lang="scss">

</style>
