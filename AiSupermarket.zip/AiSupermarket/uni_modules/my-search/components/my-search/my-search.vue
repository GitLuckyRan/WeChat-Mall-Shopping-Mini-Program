<template>
  <view class="my-search-container" :style="{'background-color':bgcolor}" @click="searchBoxHander">
    <view class="my-search-box" :style="{'border-radius':radius+'px'}">
      <uni-icons type="search" size="17"></uni-icons>
      <text class="placeholder">搜索</text>
    </view>
  </view>
</template>
<script>
  export default {
    props: {
      bgcolor: {
        type: String,
        default: '#f9f9f9'
      },
      radius: {
        type: Number,
        default: 15
      }
    },
    data() {
      return {

      }
    },
    methods: {
      searchBoxHander() {
        this.$emit('click')
      },
    }

  }
</script>
<style lang="scss">
  .my-search-container {
    height: 45px;
    // background-color: #c00000;
    display: flex;
    align-items: center;
    padding: 0 10px;
    background-color: #f9f9f9;

    .my-search-box {
      height: 36px;
      background-color: white;
      // border-radius: 15px;
      width: 100%;
      display: flex;
      justify-content: center;
      align-items: center;

      .placeholder {
        font-size: 15px;
        margin-left: 5px;
      }
    }
  }
</style>
