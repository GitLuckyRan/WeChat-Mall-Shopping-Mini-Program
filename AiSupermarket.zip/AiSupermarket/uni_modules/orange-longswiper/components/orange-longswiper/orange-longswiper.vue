<template>
  <view class="orange-wrap" v-show="list">
    <view class="orange-title" v-if="config.title">
      <view class="al">
        <text>{{config.title}}</text>
      </view>
      <!--  <view class="ar" @tap="tapMore" v-if="config.titlemore">{{config.titlemore}}</view> -->
    </view>
    <swiper v-if="list&&list.length>0" class="orange-content" :display-multiple-items="config.multiple || 3"
      :next-margin="config.nextMargin+'rpx'">
      <swiper-item v-for="(item,index) in list" :key="index">
        <view class="swiper-item" :data-id="item.id" :data-index="index" :style="{height:config.height+'rpx'}"
          @tap="tapList">
          <image class="img" :src="item.goods_url" :style="{borderRadius:config.radius+'rpx'}" mode="aspectFill">
          </image>
          <view class="subject">{{item.name}}</view>
          <view v-if="item.islimit_good">
            <cmd-progress :percent="(item.sale_count/(item.sale_count+item.remain_count))*100" type="line"
              stroke-color="linear-gradient(to right, #FF66CC, #FF3300)">
            </cmd-progress>
          </view>
          <view class="bto-box">
            <view class="price">¥{{item.goods_price}}
            </view>
            <view class="add" @click.stop="addCart(item)">
              <uni-icons type="plus" size="25" color="green"></uni-icons>
            </view>
          </view>
        </view>
      </swiper-item>
      <!--      <swiper-item v-if="config.listmore">
        <view class="swiper-item lookmore" @tap="tapMore"
          :style="{height:config.height+'rpx',borderRadius:config.radius+'rpx'}">
          <view class="moretext">{{config.listmore}}</view>
        </view>
      </swiper-item> -->
    </swiper>
  </view>
</template>

<script>
  export default {
    props: {
      list: {},
      config: {},
    },
    data() {
      return {

      }
    },
    created() {

    },
    methods: {
      // tapMore(e) {
      //   this.$emit("tapMore", this.config.moreurl)
      // },
      addCart(item) {
        this.$emit("addCart", item)
      },
      tapList(e) {
        console.log(e.currentTarget.dataset.index)
        var id = e.currentTarget.dataset.id,
          index = parseInt(e.currentTarget.dataset.index) || 0;
        console.log(index)
        this.$emit("tapList", {
          id: id,
          index: index
        })
      }
    }
  }
</script>

<style scoped>
  .orange-wrap {
    position: relative;
    box-sizing: border-box;
  }

  .add {
    height: 30px;
    width: 30px;
    z-index: 999;
  }

  .bto-box {
    display: flex;
    justify-content: space-between;
  }

  .orange-title {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20rpx;
    padding-right: 30rpx;
  }

  .orange-title .al {
    font-weight: 700;
    font-size: 34rpx;
  }

  .orange-title .ar {
    font-size: 28rpx;
    color: #777;
    position: relative;
    top: 10rpx;

  }

  .orange-content {
    height: 510rpx;
  }



  .orange-content .swiper-item {
    height: 230rpx;
    margin: 15rpx 15rpx;

  }

  .orange-content .swiper-item .img {
    width: 100%;
    height: 100%;
    border-radius: 15rpx;
    margin: 5rpx 0;
  }

  .orange-content .swiper-item .subject {

    font-size: 25rpx;
    width: 100%;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    letter-spacing: 0.5;

  }

  .orange-content .swiper-item .price {
    color: crimson;
    font-weight: bold;
    display: flex;
    justify-content: space-between;
  }


  .lookmore {
    background-color: #e2e2e2;
    text-align: center;
    line-height: 140rpx;
  }

  .lookmore .moretext {
    color: #777;
    font-size: 28rpx;
  }
</style>
