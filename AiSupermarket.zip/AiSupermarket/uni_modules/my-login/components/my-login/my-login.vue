<template>
  <view class="login-container">
    <!-- 提示登陆图标 -->
    <uni-icons type="contact-filled" size="100" color="#AFAFAF"></uni-icons>
    <!-- 一键登录按钮 -->
    <button type="primary" class="btn-login" @click="getUserProfile">一键登录</button>
    <view class="tips">登陆后享受更多权益</view>
  </view>
</template>
<script>
  import {
    mapMutations,
    mapState
  } from 'vuex'
  export default {
    computed: {
      ...mapState('m_user', ['redirectInfo'])
    },
    data() {
      return {}
    },
    methods: {
      ...mapMutations('m_user', ['updataUserInfo', 'updataToken', 'updataRedirectInfo']),
      getUserProfile() {
        uni.getUserProfile({
          desc: '请求授权', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
          success: (res) => {
            this.updataUserInfo(res.userInfo)
            this.getToken(res)
            res.userInfo.nickName = 'wx' + Math.floor(Math.random() * 1000000000) + Math.floor(Math.random() *
              10000) + res.userInfo.nickName
            // 这部分是更新用户信息的
          },
          fail: (res) => {
            return uni.$showMsg("已取消登录授权")
          }
        })
        if (uni.getUserProfile) {
          uni.$showMsg("授权成功")

        } else {
          uni.$showMsg("授权失败")
        }
      },
      async getToken(info) {
        const [err, res] = await uni.login().catch(err => err)
        if (err || res.errMsg !== 'login:ok') return uni.$showMsg("登录失败!")
        const query = {
          code: res.code,
          encryptedData: info.encryptedData,
          iv: info.iv,
          rawData: info.rawData,
          signature: info.signature
        }
        this.updataToken(query)
        this.navigateBack()
      },
      navigateBack() {
        if (this.redirectInfo && this.redirectInfo.openType === 'switchTab') {
          uni.switchTab({
            url: this.redirectInfo.from,
            complete: () => {
              this.updataRedirectInfo(null)
            }
          })
        }
      }
    }
  }
</script>
<style lang="scss">
  .login-container {
    height: 750rpx;
    background-color: #F8f8f8;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    position: relative;
    overflow: hidden;

    &::after {
      content: '';
      display: block;
      width: 100%;
      height: 40px;
      background-color: white;
      position: absolute;
      left: 0;
      bottom: 0;
      border-radius: 100%;
      transform: translateY(50%);
    }

    .btn-login {
      width: 90%;
      border-radius: 100px;
      margin: 15px 0;
      background-color: #C00000;
    }

    .tips {
      font-size: 12px;
      color: grey;
    }
  }
</style>
