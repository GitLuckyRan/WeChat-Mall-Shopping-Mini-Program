<template>
  <view class="my-settle-container">
    <label class="radio" @click="checkAllHanlder">
      <radio color="#C00000" :checked="isFullCheck" /><text>全选</text>
    </label>
    <view class="amount-box">
      合计：<text>{{checkedGoodsAmount}}</text>
    </view>
    <view class="btn-settle" @click="settlement">结算({{checkedCount}})</view>
  </view>
</template>
<script>
  import {
    mapGetters,
    mapMutations,
    mapState
  } from 'vuex'
  export default {
    computed: {
      ...mapGetters('m_cart', ['total', 'checkedCount', 'checkedGoodsAmount']),
      ...mapGetters('m_user', ['addstr']),
      ...mapState('m_user', ['token', 'userInfo']),
      ...mapState('m_cart', ['cart']),
      isFullCheck() {
        return this.total === this.checkedCount
      }
    },
    data() {
      return {
        seconds: 3,
        timer: null,
        flag: false,
        limitLocation: [],
        MonenyCount: 0,
        limitTime: false
      }
    },
    methods: {
      ...mapMutations('m_cart', ['updataAllGoodsState', 'removeGoodsById']),
      ...mapMutations('m_user', ['updataRedirectInfo']),
      checkAllHanlder() {
        // console.log(!this.isFullCheck)
        this.updataAllGoodsState(!this.isFullCheck)
      },
      addCheckCount() {
        Promise.all([this.MonenyCount = parseFloat(this.checkedGoodsAmount) + 5]).then(res => {
          this.payOrder()
        })
      },
      async locationName() {
        const location = uniCloud.importObject('location')
        const {
          data: res
        } = await location.search()
        this.limitLocation = res
        for (let i = 0; i < res.length; i++) {
          if (this.addstr.includes(this.limitLocation[i].name)) {
            this.flag = true
          }
        }
      },
      settlement() {
        Promise.all([
          this.locationName(),
          this.checkLimit()

        ]).then(res => {
          if (this.limitTime) return uni.$showMsg("限定商品请在相应时间段购买!")
          if (!this.checkedCount) return uni.$showMsg("请选择您要结算的商品!")
          if (!this.addstr) return uni.$showMsg("请选择您要收货的地址!")
          if (!this.flag) return uni.showModal({
            content: "收货地址超出配送范围！"
          })
          if (!this.token) return this.delayNavigate()
          this.check()
          console.log("最后执行")
        })
        // this.locationName()
        // if (!this.checkedCount) return uni.$showMsg("请选择您要结算的商品!")
        // if (!this.addstr) return uni.$showMsg("请选择您要收货的地址!")
        // if (!this.flag) return uni.showModal({
        //   content: "收货地址超出配送范围！"
        // })
        // if (!this.token) return this.delayNavigate()
        // this.check()
      },
      checkLimit() {

        let goodsTime = this.cart.filter(x => x.goods_state).map(x => ({
          goods_sn: x.goods_sn,
        }))
        for (let i = 0; i < goodsTime.length; i++) {
          let hour = new Date().getHours()
          if (goodsTime[i].goods_sn.charAt(0) == 'M') {
            if (hour < 7 || hour > 9) {
              this.limitTime = true
              return
            }
          }
          if (goodsTime[i].goods_sn.charAt(0) == 'A') {
            if (hour < 11 || hour > 13) {
              this.limitTime = true
              return
            }
          }
          if (goodsTime[i].goods_sn.charAt(0) == 'N') {
            if (hour < 17 || hour > 19) {
              this.limitTime = true
              return
            }
          }
        }
        console.log(this.limitTime)

      },
      check() {
        var that = this;
        if (this.checkedGoodsAmount < 100) {
          uni.showModal({
            title: '提示',
            content: '商品总价不足100元是另加配送费5元' + '总计：' + (parseFloat(that.checkedGoodsAmount) + 5).toFixed(2),
            success: function(res) {
              if (res.confirm) {
                console.log(that)
                that.addCheckCount()
              } else if (res.cancel) {
                console.log('用户点击取消');
              }
            }
          });
        } else {
          this.MonenyCount = parseFloat(this.checkedGoodsAmount).toFixed(2)
          this.payOrder()
        }
      },
      async payOrder() {
        console.log('触发支付')
        console.log(this.MonenyCount)

        //1创建订单//2组织订单对象
        const orderInfo = {
          order_price: this.MonenyCount,
          username: this.userInfo.nickName,
          goods: this.cart.filter(x => x.goods_state).map(x => ({
            goods_sn: x.goods_sn,
            goods_count: x.goods_count,
            goods_price: x.goods_price,
            name: x.name,
            goods_state: x.goods_state,
            goods_small_logo: x.goods_small_logo
          }))
        }
        console.log(orderInfo.order_price)
        //3发起请求创建订单
        const getsMoney = uniCloud.importObject('user-payorder')
        const result = await getsMoney.getsMoney(orderInfo)
        if (result.errcode == 200) {
          const order = {
            orderList: result.data + '',
            orderprice: this.MonenyCount,
            order_date: parseInt(result.data / 1000),
            order_good: orderInfo.goods,
            order_owner: this.userInfo.nickName,
            address: this.addstr
          }
          this.createOrders(order)
          console.log(result.data)
          console.log(parseInt(result.data / 1000))
        } else {
          uni.$showMsg("余额不足~")
        }

        // if (res.meta.status !== 200) return uni.$showMsg('创建订单失败！')
        //4获取订单编号
        // const orderNumber = res.message.order_number
        // console.log(orderNumber)
      },
      async createOrders(order) {
        const createOrder = uniCloud.importObject('goods-order')
        const orders = await createOrder.createOrder(order)
        if (orders.errcode == 300) {
          uni.showToast({
            title: "商品数量不足~",
            icon: 'error'
          })
          return
        }
        if (order) {
          this.flag = false
          uni.showToast({
            title: "支付成功~",
            icon: 'success'
          })
          console.log('order信息')
          for (let i = 0; i < order.order_good.length; i++) {
            this.removeGoodsById(order.order_good[i])

          }
        } else {
          uni.showToast({
            title: "支付失败~",
            icon: 'error'
          })
        }
      },
      delayNavigate() {
        this.showTips(this.seconds)
        this.timer = setInterval(() => {
          this.seconds--
          if (this.seconds <= 0) {
            clearInterval(this.timer)
            this.seconds = 3
            uni.switchTab({
              url: '/pages/my/my',
              success: () => {
                this.updataRedirectInfo({
                  openType: 'switchTab',
                  from: '/pages/cart/cart'
                })
              }
            })
            return
          }
          this.showTips(this.seconds)
        }, 1000)
      },
      showTips(n) {
        uni.showToast({
          icon: 'none',
          title: '请先登录账号' + n + '秒后实现跳转!',
          duration: 1500,
          mask: true
        })
      }
    },
  }
</script>
<style lang="scss">
  .my-settle-container {
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: fixed;
    bottom: 0;
    left: 0;
    height: 50px;
    width: 100%;
    background-color: white;
    font-size: 14px;
    padding-left: 5px;

    .radio {
      display: flex;
      align-items: center;
    }

    .amount-box {
      color: #C00000;
      font-weight: bolder;
    }

    .btn-settle {
      background-color: #C00000;
      height: 50px;
      line-height: 50px;
      align-items: center;
      color: white;
      padding: 0 10px;
      min-width: 100px;
      text-align: center;
    }
  }
</style>
