<template>
  <view class="my-userinfo-container">
    <!-- 头像昵称区域 -->
    <view class="top-box">
      <button style="border: none;" plain="true" open-type="chooseAvatar" @chooseavatar="onChooseAvatar">
        <image :src="userInfo.avatarUrl" class="avater"></image>
      </button>
      <view class="nickname">{{userInfo.nickName}}</view>
    </view>
    <!-- 用户浏览商品详情 -->
    <view class="panel-list">
      <!-- 第一个面板 -->
      <view class="panel">
        <view class="panel-body">
          <view class="panel-item">
            <text id="money">{{Money | tofixed}}</text>
            <text>账户余额</text>
          </view>
          <view class="panel-item" @click="gotoInterg">
            <text>{{integral}}</text>
            <text>账户积分</text>
          </view>
          <view class="panel-item">
            <uni-icons type="refreshempty" @click="refreshMoney" size="30"></uni-icons>
            <text>刷新</text>
          </view>
        </view>

      </view>
      <view class="panel">
        <view class="panel-list-item" @click="checkOrders">
          <text>我的订单</text>
          <uni-icons type="arrowright" size="15"></uni-icons>
        </view>
        <view class="panel-list-item" @click="chooseAdress">
          <text>收货地址</text>
          <uni-icons type="arrowright" size="15"></uni-icons>
        </view>
        <view class="panel-list-item" @click="kefu">
          <text>联系客服</text>
          <uni-icons type="arrowright" size="15"></uni-icons>
        </view>
        <view class="panel-list-item" @click="toFeedBack">
          <text>问题反馈</text>
          <uni-icons type="arrowright" size="15"></uni-icons>
        </view>
        <!--     <view class="panel-list-item" @click="logout">
          <text>退出登录</text>
          <uni-icons type="arrowright" size="15"></uni-icons>
        </view> -->
      </view>
    </view>

    <!--   <button @click="getLocation" type="primary">获取地址</button> -->
  </view>

</template>
<script>
  import {
    mapState,
    mapMutations
  } from 'vuex'
  import {
    functions,
    update
  } from 'lodash'

  export default {
    computed: {
      // 将 m_user 模块中的 userInfo 映射到当前页面中使用
      ...mapState('m_user', ['userInfo', 'token']),
    },
    data() {
      return {
        mobile: '',
        u_mobile: null,
        Money: 0,
        dfMoney: 0,
        integral: 0,
        inputBox: false,
        lat1: 1,
        lng: 0
      }
    },
    created() {
      this.checkMoney()
      console.log(this.Money)
    },
    methods: {
      ...mapMutations('m_user', ['updataAdderss', 'updataUserInfo', 'updataToken', 'updateFace', 'updateName']),
      // getLocation: async function() {
      //   // 使用promise 判断地理位置是否授权  
      //   return new Promise((resolve, reject) => {
      //     uni.getSystemInfo({
      //       success({
      //         locationEnabled,
      //         locationAuthorized
      //       }) {
      //         // locationEnabled 判断手机定位服务是否开启  
      //         // locationAuthorized 判断定位服务是否允许微信授权  
      //         if (!locationEnabled && !locationAuthorized) {
      //           // GPS未开启 与 GPS未给微信授权定位服务  
      //           uni.showModal({
      //             title: '需要获取地理位置',
      //             content: 'GPS已开启，GPS未给微信授权定位服务',
      //             showCancel: false
      //           });
      //           reject("GPSnotOpen");
      //         } else if (locationEnabled && !locationAuthorized) {
      //           // GPS已开启 与 GPS未给微信授权定位服务  
      //           uni.showModal({
      //             title: '需要获取地理位置',
      //             content: 'GPS已开启，GPS未给微信授权定位服务',
      //             showCancel: false
      //           });
      //           reject("GPSauthorization");
      //         } else if (locationEnabled && locationAuthorized) {
      //           /*  
      //               GPS已开启 与 GPS已给微信授权定位服务 
      //               判断微信小程序位置信息是否开启 
      //           */
      //           uni.authorize({
      //             scope: "scope.userLocation",
      //             success() {
      //               // 微信小程序位置信息已开启  
      //               uni.getLocation({
      //                 success({
      //                   latitude,
      //                   longitude
      //                 }) {
      //                   // latitude; 纬度  
      //                   // longitude; 经度  
      //                   this.longitude = longitude
      //                   this.latitude = latitude
      //                   resolve({
      //                     latitude,
      //                     longitude
      //                   });
      //                 }
      //               });
      //             },
      //             fail() {
      //               // 微信小程序位置信息未开启  
      //               uni.getSetting({
      //                 success: (res) => {
      //                   let authStatus = res.authSetting['scope.userLocation'];
      //                   if (!authStatus) {
      //                     uni.showModal({
      //                       title: '需要获取地理位置',
      //                       content: '需要获取您的位置信息，请在设置界面打开相关权限',
      //                       success: (res) => {
      //                         if (res.confirm) {
      //                           uni.openSetting()
      //                         }
      //                         reject()
      //                       }
      //                     })
      //                   } else {
      //                     uni.showModal({
      //                       title: '打卡失败',
      //                       content: '无法获取位置信息',
      //                       showCancel: false
      //                     });
      //                     reject('用户拒绝授权')
      //                     // 拒绝后的回调，这个弹窗应该关掉    
      //                   }
      //                 }
      //               })
      //               // uni.showModal({  
      //               //  title: '需要获取地理位置',    
      //               //  content: '微信小程序位置信息未开启',    
      //               //  showCancel: false    
      //               // });  
      //               // reject("weixinPositionNotOpen");  
      //             }
      //           })
      //         }
      //       },
      //       fail(err) {
      //         let reg = /request:fail/;
      //         if (reg.test(err.errMsg)) {
      //           // 无网络  
      //           reject("noNetWork");
      //         } else {
      //           // 请求超时'  
      //           reject("requestTimeOut");
      //         }
      //       }
      //     })
      //   });
      // },
      async logout() {
        const [err, succ] = await uni.showModal({
          title: '提示',
          content: '确认退出登录吗?'
        }).catch(err => err)
        if (succ && succ.confirm) {
          // 用户确认了退出登录的操作
          // 需要清空 vuex 中的 userinfo、token 和 address
          this.updataUserInfo({})
          this.updataToken('')
          this.updataAdderss({})
        }
      },
      refreshMoney() {
        this.checkMoney()
      },
      toFeedBack() {
        uni.navigateTo({
          url: '/pages/common/feedback/feedback'
        })
      },
      refresh() {
        // console.log(this.u_mobile)
        this.checkMoney()
      },
      // 修改头像
      onChooseAvatar({
        detail: {
          avatarUrl: face
        }
      }) {
        console.log("dsa")
        this.updateFace(face)
      },
      //修改用户名{
      onBlur({
        detail: {
          value: name
        }
      }) {
        if (name.indexOf(' ') != -1 || !name) {
          this.inputBox = false;
          return
        }
        this.updateNa(name)
        this.updateName(name)
        this.inputBox = false
      },
      checkModbile(mobile) {
        var re = /^1[3,4,5,6,7,8,9][0-9]{9}$/;
        var result = re.test(mobile);
        if (!result) {
          uni.$showMsg("手机号不正确请重新输入!")
          return false;
        }
        return true;
      },
      async updateNa(newName) {
        const update = uniCloud.importObject('adds-users')
        const name = {
          old: this.userInfo.nickName,
          new: newName
        }
        const {
          data: res
        } = await update.updateUser(name)
        console.log(res)
      },
      async addUser() {
        console.log('添加用户')
        const addUser = uniCloud.importObject('adds-users')
        const add = {
          role_name: this.userInfo.nickName
        }
        const search = uniCloud.importObject('adds-users')
        const {
          data: result
        } = await search.search(this.userInfo.nickName)
        if (result.affectedDocs == 0) {
          const {
            data: res
          } = await addUser.addUser(add)
        } else {
          return
        }
      },
      async checkMoney() {
        this.addUser()
        const checkMoney = uniCloud.importObject('adds-users')
        const {
          data: res
        } = await checkMoney.getMoney(this.userInfo.nickName)
        console.log(res[0].money)
        if (!res[0].money) {
          this.Money = 0
        } else {
          this.Money = res[0].money
        }
        if (!res[0].integral) {
          this.integral = 0
        } else {
          this.integral = res[0].integral
        }
      },
      checkOrders() {
        uni.navigateTo({
          url: '/subpkg/orders/orders'
        })
      },
      async chooseAdress() {
        // 1. 调用小程序提供的 chooseAddress() 方法，即可使用选择收货地址的功能
        //    返回值是一个数组：第 1 项为错误对象；第 2 项为成功之后的收货地址对象
        const [err, succ] = await uni.chooseAddress().catch(err => err)
        console.log(succ)
        // 2. 用户成功的选择了收货地址
        if (succ && succ.errMsg === 'chooseAddress:ok') {
          // 更新 vuex 中的收货地址
          this.updataAdderss(succ)
        }
      },
      kefu() {
        uni.showToast({
          title: "电话:10000000",
          duration: 2000,
          icon: 'none'
        })
      },
      gotoInterg() {
        uni.navigateTo({
          url: '/subpkg/interg-list/interg-list'
        })
      }
    },
    filters: {
      tofixed(num) {
        return Number(num).toFixed(2)
      }
    }
  }
</script>
<style lang="scss">
  .my-userinfo-container {
    height: 100%;
    background-color: #efefef;

    .top-box {
      height: 400rpx;
      background-color: #C00000;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;

      .avater {
        display: block;
        height: 90px;
        width: 90px;
        border-radius: 45px;
        border: 2px solid white;
        box-shadow: 0 1px 5px black;
      }

      .nickname {
        color: white;
        font-weight: bold;
        font-size: 16px;
        margin-top: 10px;
      }
    }
  }

  .panel-list {
    padding: 0 10px;
    position: relative;
    top: -10px;

    .panel {
      background-color: white;
      border-radius: 5px;
      margin-bottom: 8px;

      .panel-list-item {
        height: 45px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin: 0 10px;
        font-size: 14px;
      }

      .panel-title {
        line-height: 45px;
        padding-left: 10px;
        font-size: 15px;
        border-bottom: 1px solid #f4f4f4;
      }

      .panel-body {
        display: flex;
        justify-content: space-around;

        .panel-item {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: space-around;
          font-size: 13px;
          padding: 10px 0;

          .icon {
            width: 35px;
            height: 35px;
          }
        }
      }
    }
  }
</style>
