<template>
  <view class="goods-item">
    <!-- 左侧盒子        -->
    <view class="goods-item-left">
      <radio :checked="goods.goods_state" color="#C00000" v-if="showRadio" @click="radioClickHandler"></radio>
      <image :src="goods.goods_small_logo|| defaultPic" class="goods-pic" @click="toDetail"></image>
    </view>

    <!-- 右侧盒子 -->
    <view class="goods-item-right">
      <view class="goods-name" @click="toDetail">{{goods.name}}</view>
      <view class="goods_info-box">
        <view class="goods-price" @click="toDetail">¥{{goods.goods_price | tofixed}}</view>
        <uni-number-box :min="1" :value="goods.goods_count" v-if="showNum" @change="numClickChange"
          :disabled=" goods.goods_limit">
        </uni-number-box>
      </view>
    </view>

  </view>
</template>
<script>
  export default {
    props: {
      goods: {
        type: Object,
        default: {}
      },
      showRadio: {
        type: Boolean,
        default: false
      },
      showNum: {
        type: Boolean,
        default: false
      },
    },
    data() {
      return {
        defaultPic: 'https://img3.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png',
        goods_state: this.goods.goods_state
      };
    },
    methods: {
      radioClickHandler() {
        this.$emit('radio-chang', {
          goods_sn: this.goods.goods_sn,
          goods_state: !this.goods.goods_state
        })
      },
      numClickChange(val) {
        if (parseInt(this.goods.goods_sn.charAt(0)) >= 0 && parseInt(this.goods.goods_sn.charAt(0)) < 10) {
          this.$emit('num-change', {
            goods_sn: this.goods.goods_sn,
            goods_count: +val
          })
        } else {
          uni.showToast({
            title: "限购一件",
            icon: "fail",
          })
          this.goods.goods_count = 1
          return
        }
      },
      toDetail(goods) {
        uni.navigateTo({
          url: '/subpkg/goods_details/goods_details?goods_sn=' + this.goods.goods_sn
        })
      },
    },
    filters: {
      tofixed(num) {
        return Number(num).toFixed(2)
      }
    }
  }
</script>
<style lang="scss">
  .goods-item {
    display: flex;
    margin: 5px 5px;
    background-color: #ffffff;
    height: 115px;
    border-radius: 5px;

    .goods-item-left {
      margin-right: 5px;
      display: flex;
      justify-content: space-between;
      align-items: center;

      .goods-pic {
        width: 100px;
        height: 100px;
        border-radius: 5px;
        display: block;
      }
    }

    .goods-item-right {
      display: flex;
      flex: 1;
      flex-direction: column;
      justify-content: space-between;
      margin: 2px 2px;

      .goods-name {
        font-size: 13px;
        letter-spacing: 0.5px;
      }

      .goods_info-box {
        display: flex;
        justify-content: space-between;
        align-items: center;

        .goods-price {
          font-size: 16px;
          font-weight: 550;
          color: crimson;
        }
      }
    }
  }
</style>
