<template>
  <view>
    <!-- 选这收货地址按钮 -->
    <view class="btnChoose" v-if="JSON.stringify(address)==='{}'">
      <button type="primary" size="mini" @click="chooseAdress">请选择收货地址+</button>
    </view>
    <!-- 收获地址详细信息 -->
    <view class="info" v-else @click="chooseAdress">
      <view class="row1">
        <view class="row1-left">收货人：{{address.userName}}</view>
        <view class="row1-right">
          <view class="phone">电话：<text>{{address.telNumber}}</text></view>
          <uni-icons type="arrowright" size="16"></uni-icons>
        </view>
      </view>
      <view class="row2">
        <view class="row2-left">收货地址：</view>
        <view class="row2-right">{{addstr}}</view>
      </view>
    </view>
    <!--    <image src="/static/cart_box/bot.png" class="address-border"></image> -->
  </view>
</template>
<script>
  import {
    mapState,
    mapMutations,
    mapGetters,
  } from 'vuex'
  export default {
    computed: {
      ...mapState('m_user', ['address']),
      ...mapGetters('m_user', ['addstr']),
    },
    data() {
      return {
        // 收货地址
      }
    },
    methods: {
      ...mapMutations('m_user', ['updataAdderss']),
      async chooseAdress() {
        // 1. 调用小程序提供的 chooseAddress() 方法，即可使用选择收货地址的功能
        //    返回值是一个数组：第 1 项为错误对象；第 2 项为成功之后的收货地址对象
        const [err, succ] = await uni.chooseAddress().catch(err => err)
        // 2. 用户成功的选择了收货地址
        if (succ && succ.errMsg === 'chooseAddress:ok') {
          // 更新 vuex 中的收货地址
          this.updataAdderss(succ)
        }
      }
    }
  }
</script>
<style lang="scss">
  .address-border {
    display: block;
    width: 100%;
    height: 5px;
  }

  .btnChoose {
    height: 70px;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .info {
    display: flex;
    flex-direction: column;
    height: 70px;
    justify-content: center;
    padding: 0, 5px;
    font-size: 14px;

    .row1 {
      display: flex;
      justify-content: space-between;

      .row1-left {}

      .row1-right {
        display: flex;
        align-items: center;

        .phone {
          margin-right: 5px;
        }
      }
    }

    .row2 {
      display: flex;
      align-items: center;
      margin-top: 5px;
      padding-bottom: 5px;

      .row2-left {
        white-space: nowrap;
      }

      .row2-right {}
    }
  }
</style>
