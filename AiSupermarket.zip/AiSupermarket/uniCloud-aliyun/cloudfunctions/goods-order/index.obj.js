const {
  result
} = require("goods-utils");
const db = uniCloud.database()
module.exports = {
  _before: function() { // 通用预处理器
    this.startTime = Date.now()
    // let body = this.getHttpInfo().body; //获取传参数值
    // if (!body) throw result(400, "required")
    // this.params = JSON.parse(this.getHttpInfo().body) //
    this.params = this.getParams()
  },
  createOrder: async function() {
    let goods = this.params[0].order_good
    for (let i = 0; i < goods.length; i++) {
      const res = await db.collection("order").add({
        orderList: this.params[0].orderList,
        orderprice: goods[i].goods_price,
        addres: this.params[0].address,
        order_date: this.params[0].order_date,
        order_good: goods[i].goods_sn,
        order_owner: this.params[0].order_owner,
        ordercount: goods[i].goods_count,
      })
      const goodsInfo = uniCloud.importObject('goods-order')
      const res1 = await goodsInfo.goodsInfo(goods[i].goods_sn)
      const res2 = res1.data
      console.log('res2的内容：' + res2)
      if (res2[0].remainCount < goods[i].goods_count) {
        return result(300, "failure", 0, 0);
      }
      const subCount = await db.collection("as-goods").where({
        goods_sn: goods[i].goods_sn
      }).update({
        remain_count: res2[0].remainCount - goods[i].goods_count,
        sale_count: res2[0].saleCount + goods[i].goods_count,
      })
      const subCountLimit = await db.collection("limit-goods").where({
        goods_sn: goods[i].goods_sn
      }).update({
        remain_count: res2[0].remainCount - goods[i].goods_count,
        sale_count: res2[0].saleCount + goods[i].goods_count,
      })
    }

    return result(200, "success", 0, 0);
  },

  goodsInfo: async function(goods_sn) {
    const good = await db.collection("as-goods").where({
      goods_sn: goods_sn
    }).get()
    const limitgood = await db.collection("limit-goods").where({
      goods_sn: goods_sn
    }).get()
    let arr = good.data.map(item => {
      return {
        remainCount: parseInt(item.remain_count),
        saleCount: parseInt(item.sale_count)
      }
    })
    const arr1 = limitgood.data.map(item => {
      return {
        remainCount: parseInt(item.remain_count),
        saleCount: parseInt(item.sale_count)
      }
    })
    arr = [...arr, ...arr1]
    console.log('arr内容：' + arr)
    return result(200, "success", arr, 1)
  },
  affirm: async function() {
    const res = await db.collection("order").where({
      orderList: this.params[0]
    }).update({
      order_affirm: true
    })
    return result(200, "success", res, 1);
  },
  _after: function(error, result) {
    if (error) {
      throw error
    }
    result.timeCost = Date.now() - this.startTime
    return result
  }
}
