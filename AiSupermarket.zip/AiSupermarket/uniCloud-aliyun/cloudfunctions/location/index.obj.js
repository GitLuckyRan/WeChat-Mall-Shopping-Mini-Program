const {
  result
} = require("goods-utils");
const db = uniCloud.database()
module.exports = {
  _before: function() { // 通用预处理器
    this.startTime = Date.now()
  },
  search: async function() {
    const search = await db.collection("location").where({}).get()
    const arr = search.data.map(item => {
      return {
        name: item.name,
        integral: item.time
      }
    })
    return result(200, "success", arr, search.affectedDocs);
  },
  _after: function(error, result) {
    if (error) {
      throw error
    }
    result.timeCost = Date.now() - this.startTime
    return result
  }
}
