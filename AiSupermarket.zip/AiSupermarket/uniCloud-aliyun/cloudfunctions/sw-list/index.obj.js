const {
  result
} = require("goods-common");
const db = uniCloud.database()
module.exports = {
  _before: function() { // 通用预处理器
    this.startTime = Date.now()
    let body = this.getHttpInfo().body;
    if (!body) throw result(400, "require")
  },
  get: async function() {
    const res = await db.collection("as-swiper").where({
      "sw_statue": true
    }).get()
    const arr = res.data.map(item => {
      return {
        category: item.category,
        icon: item.sw_url.url
      }
    })
    return result(200, "success", arr, res.affectedDocs);
  },
  _after: function(error, result) {
    if (error) {
      throw error
    }
    result.timeCost = Date.now() - this.startTime
    return result
  }
}
