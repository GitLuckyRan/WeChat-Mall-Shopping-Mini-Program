const {
  result
} = require("goods-utils");
const db = uniCloud.database()
module.exports = {
  _before: function() { // 通用预处理器
    this.startTime = Date.now()
    // let body = this.getHttpInfo().body; //获取传参数值
    // if (!body) throw result(400, "required")
    // this.params = JSON.parse(this.getHttpInfo().body) //
    this.params = this.getParams()
  },
  IntergalOrder: async function() {
    const res = await db.collection("intergal").add({
      order_date: new Date().getTime(),
      order_good: this.params[0].order_good,
      order_owner: this.params[0].order_owner,
      ordercount: this.params[0].goods_count,
      orderprice: this.params[0].orderprice
    })
    return result(200, "success", res, 0);
  },
  _after: function(error, result) {
    if (error) {
      throw error
    }
    result.timeCost = Date.now() - this.startTime
    return result
  }
}
