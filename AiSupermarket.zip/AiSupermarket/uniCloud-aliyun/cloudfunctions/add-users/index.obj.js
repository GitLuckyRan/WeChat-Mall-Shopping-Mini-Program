const db = uniCloud.database()
module.exports = {
  _before: function() { // 通用预处理器
    // this.startTime = Date.now()
    // this.params = this.getParams()
  },
  // getMoney: async function() {
  //   const res = await db.collection("as-user").where({
  //     role_name: this.params[0]
  //   }).get()
  //   const arr = res.data.map(item => {
  //     return {
  //       money: item.role_money,
  //       integral: item.role_integral
  //     }
  //   })
  //   return result(200, "success", arr, res.affectedDocs);
  // },
  // addUser: async function() {
  //   const search = await db.collection("as-user").where({
  //     role_name: this.params[0],
  //   }).get()
  //   if (search.affectedDocs == 0) {
  //     let res = await db.collection("as-user").add({
  //       "role_id": this.params[0].role_id,
  //       "role_mobile": this.params[0].role_mobile,
  //       "role_name": this.params[0].role_name,
  //       "role_money": 0
  //     })
  //     return result(200, "success", res, res.affectedDocs);
  //   } else {
  //     return "存在" + this.params[0];
  //   }
  // },
  // updateUser: async function() {
  //   const update = await db.collection("as-user").where({
  //     role_name: this.params[0].old,
  //   }).update({
  //     role_name: this.params[0].new,
  //   })
  //   return result(200, "success", update, res.affectedDocs);
  // },
  // _after: function(error, result) {
  //   if (error) {
  //     throw error
  //   }
  //   result.timeCost = Date.now() - this.startTime
  //   return result
  // }
}
