const {
  result
} = require("goods-utils");
const db = uniCloud.database()
module.exports = {
  _before: function() { // 通用预处理器
    this.startTime = Date.now()
    // let body = this.getHttpInfo().body; //获取传参数值
    // if (!body) throw result(400, "required")
    // this.params = JSON.parse(this.getHttpInfo().body) //
    this.params = this.getParams()
  },
  goodCount: async function() {
    const res = await db.collection("interg-goods").where({
      goods_sn: this.params[0],
    }).get()
    const arr = res.data.map(item => {
      return {
        remainCount: item.remain_count
      }
    })
    if (arr[0].remainCount < 1) {
      return result(300, "failure", 0, 0);
    }
    return result(200, "success", arr, res.affectedDocs);
  },
  subInterg: async function() {
    // try {
    const res1 = await db.collection("as-user").where({
      role_name: this.params[0].role_name,
    }).get()
    const arr = res1.data.map(item => {
      return {
        money: item.role_money,
        integral: item.role_integral,
      }
    })
    if (this.params[0].role_integral < arr[0].integral) {
      const res = await db.collection("as-user").where({
        "role_name": this.params[0].role_name,
      }).update({
        role_integral: arr[0].integral - this.params[0].role_integral,
      })
      return result(200, "success", 1, 1);
    } else {
      return result(400, "failure", 400, 400);
    }
    // } catch {
    //   return result(400, "failure", 400, 400);
    // }
  },
  subCount: async function() {
    const res1 = await db.collection("interg-goods").where({
      goods_sn: this.params[0],
    }).get()
    const arr = res1.data.map(item => {
      return {
        remainCount: item.remain_count,
        saleCount: item.sale_count
      }
    })
    const res = await db.collection('interg-goods').where({
      goods_sn: this.params[0]
    }).update({
      remain_count: arr[0].remainCount - 1,
      sale_count: arr[0].saleCount + 1,
    })
    return result(200, "success", 1, 1);
  },
  getInterg: async function() {
    const res = await db.collection("interg-goods").where({
      is_on_sale: true,
    }).get()
    const arr = res.data.map(item => {
      return {
        goods_price: item.goods_price,
        name: item.name,
        goods_url: item.goods_url.url,
        goods_sn: item.goods_sn,
        remain_count: item.remain_count,
        sale_count: item.sale_count
      }
    })
    return result(200, "success", arr, res.affectedDocs);
  },
  _after: function(error, result) {
    if (error) {
      throw error
    }
    result.timeCost = Date.now() - this.startTime
    return result
  }
}
