const {
  result
} = require("goods-utils");
const db = uniCloud.database()
module.exports = {
  _before: function() { // 通用预处理器
    this.startTime = Date.now()
    this.params = this.getParams()
    if (!this.params) throw result(400, "required")
  },
  goodsOrder: async function() {
    let res1 = await db.collection("order").where({
      order_owner: this.params[0].nickName,
    }).count()
    const res = await db.collection("order").where({
      order_owner: this.params[0].nickName,
    }).skip((this.params[0].pagenum - 1) * 6).limit(6).get()
    const arr = res.data.map(item => {
      return {
        orderList: item.orderList,
        orderprice: item.orderprice,
        ordercount: item.ordercount,
        order_good: item.order_good,
        order_affirm: item.order_affirm
      }
    })
    return result(200, "success", res, res1.total);
  },
  _after: function(error, result) {
    if (error) {
      throw error
    }
    result.timeCost = Date.now() - this.startTime
    return result
  }
}
