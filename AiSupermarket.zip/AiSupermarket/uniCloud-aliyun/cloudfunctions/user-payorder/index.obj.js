const {
  result
} = require("goods-utils");
const db = uniCloud.database()
module.exports = {
  _before: function() { // 通用预处理器
    this.startTime = Date.now()
    // let body = this.getHttpInfo().body; //获取传参数值
    // if (!body) throw result(400, "required")
    // this.params = JSON.parse(this.getHttpInfo().body) //
    // parseFloat(this.params[0].order_price)
    this.params = this.getParams()
  },
  getsMoney: async function() {
    const res1 = await db.collection("as-user").where({
      role_name: this.params[0].username,
    }).get()
    const arr = res1.data.map(item => {
      return {
        money: item.role_money,
        integral: item.role_integral
      }
    })
    if (arr[0].money < parseFloat(this.params[0].order_price)) {
      return result(400, "false", 0, 1);
    }
    const res2 = await db.collection("as-user").where({
      role_name: this.params[0].username,
    }).update({
      role_money: parseFloat(arr[0].money) - parseFloat(this.params[0].order_price),
      role_integral: arr[0].integral + parseInt(this.params[0].order_price)
    })
    const orderNum = new Date().getTime() * 1000 + Math.floor(Math.random() * 1000)
    return result(200, "success", orderNum, 1);
  },
  _after: function(error, result) {
    if (error) {
      throw error
    }
    result.timeCost = Date.now() - this.startTime
    return result
  }
}
