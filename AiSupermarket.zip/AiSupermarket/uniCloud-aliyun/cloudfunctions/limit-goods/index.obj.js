const {
  result
} = require("goods-utils");
const db = uniCloud.database()
module.exports = {
  _before: function() { // 通用预处理器
    this.params = this.getParams()
  },
  getLimitGoods: async function() {
    const res = await db.collection("limit-goods").where({
      "category_id": this.params[0],
      is_on_sale: true
    }).limit(6).get()
    const arr = res.data.map(item => {
      return {
        goods_price: item.goods_price,
        name: item.name,
        goods_url: item.goods_url.url,
        goods_sn: item.goods_sn,
        remain_count: item.remain_count,
        sale_count: item.sale_count,
        goods_date: item.goods_date,
        expiration_date: item.expiration_date,
        islimit_good: true
      }
    })
    return result(200, "success", arr, res.affectedDocs);
  },
  _after: function(error, result) {
    if (error) {
      throw error
    }
    result.timeCost = Date.now() - this.startTime
    return result
  }
}
