const {
  result
} = require("goods-utils");
const db = uniCloud.database()
module.exports = {
  _before: function() { // 通用预处理器
    this.startTime = Date.now()
    const params = this.getParams()
    if (!params) throw result(400, "required")
  },
  checkUserMoney: async function() {
    console.log(this.params)
    // let res = await db.collection("as-user").where({
    //   role_name: this.params,
    // })
    // return result(200, "success", res);
  },
  // addUser: async function() {
  //   let res = await db.collection("as-user").add({
  //     "role_id": this.params[0].role_id,
  //     "role_mobile": this.params[0].role_mobile,
  //     "role_name": this.params[0].role_name,
  //     "role_money": 0
  //   })
  //   return result(200, "success", res);
  // },
  // checkMoney: async function() {
  //   console.log(this.params)
  //   const res = await db.collection("as-user").where({
  //     "role_name": this.params
  //   }).get()
  //   const arr = res.data.map(item => {
  //     return {
  //       money: item.role_money
  //     }
  //   })
  //   return result(200, "success", res, 1);
  // },

  // _after: function(error, result) {
  //   if (error) {
  //     throw error
  //   }
  //   result.timeCost = Date.now() - this.startTime
  //   return result
  // }
}
