const {
  result
} = require("goods-utils");
const db = uniCloud.database()
module.exports = {
  _before: function() { //预处理器
    this.startTime = Date.now()
    this.params = this.getParams()
  },
  getLike: async function() {
    let res = {}
    let good = this.params[0]
    let goods = {}
    let res1 = []
    if (this.params[0] == 0) { //用户登录是用于数据填充
      res = await db.collection("as-goods").where({
        is_hot: true,
        is_on_sale: true
      }).limit(5).get()
    } else {
      for (i = 0; i < good.length; i++) {
        res = await db.collection("as-goods").where({
          category_id: good[i],
          is_hot: true,
          is_on_sale: true
        }).limit(2).get() //每次获取同一类商品的前两个热门产品
        let items = res.data.map(item => {
          return {
            goods_price: item.goods_price,
            name: item.name,
            goods_url: item.goods_url.url,
            goods_sn: item.goods_sn
          }
        })
        res1.push(items)
      }
      if (res1.affectedDocs < 3) { //如果用户浏览较少获取商品不足三个，添加一些热门商品
        res = await db.collection("as-goods").where({
          is_hot: true,
          is_on_sale: true
        }).limit(3).get()
        let items = res.data.map(item => {
          return {
            goods_price: item.goods_price,
            name: item.name,
            goods_url: item.goods_url.url,
            goods_sn: item.goods_sn
          }
        })
        res1.push(items)
      }
      goods = res1
    }
    return result(200, "success", goods, this.params.length);
  },
  _after: function(error, result) {
    if (error) {
      throw error
    }
    result.timeCost = Date.now() - this.startTime
    return result
  }
}
