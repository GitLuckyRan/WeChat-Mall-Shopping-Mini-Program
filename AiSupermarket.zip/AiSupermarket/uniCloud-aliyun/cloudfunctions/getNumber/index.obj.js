const {
  result
} = require("goods-utils");
const db = uniCloud.database()
module.exports = {
  _before: function() { // 通用预处理器
    this.startTime = Date.now()
    this.params = this.getParams()
  },
  getNumber: async function() {
    const res = await uniCloud.getPhoneNumber({
      appid: '__UNI__EA60AF5', // 替换成自己开通一键登录的应用的DCloud appid
      provider: 'univerify',
      apiKey: 'e8f2f2c0415bc6a0542843b3b44991b3', // 在开发者中心开通服务并获取apiKey
      apiSecret: 'b3ebfb86675c696da41e359b48145d7a', // 在开发者中心开通服务并获取apiSecret
      access_token: this.params[0].access_token,
      openid: this.params[0].openid
    })
    console.log('电话：' + res); // res里包含手机号
    return result(200, "success", arr, res.affectedDocs);
  },
  _after: function(error, result) {
    if (error) {
      throw error
    }
    result.timeCost = Date.now() - this.startTime
    return result
  }
}
