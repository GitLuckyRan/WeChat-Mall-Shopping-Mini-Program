const {
  result
} = require("goods-utils");
const db = uniCloud.database()
module.exports = {
  _before: function() { // 通用预处理器
    this.startTime = Date.now()
    this.params = this.getParams()
  },
  search: async function() {
    const res = await db.collection("feedback-list").where({
      "_id": this.params[0]
    }).get()
    const arr = res.data.map(item => {
      return {
        images: item.images
      }
    })
    const images = []
    for (let i = 0; i < arr[0].images.length; i++) {
      images.push(arr[0].images[i].url)
    }
    return result(200, "success", images, res.affectedDocs);
  },
  toFeedBack: async function() {
    const res = await db.collection("feedback-list").add({
      feedbackContent: this.params[0].feedbackContent,
      mobile: this.params[0].mobile,
      images: this.params[0].images,
      isRead: false
    })
    return result(200, "success", res, res.affectedDocs);
  },

  _after: function(error, result) {
    if (error) {
      throw error
    }
    result.timeCost = Date.now() - this.startTime
    return result
  }
}
