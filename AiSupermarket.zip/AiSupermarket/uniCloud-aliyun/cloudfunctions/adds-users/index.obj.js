const {
  result
} = require("goods-utils");
const db = uniCloud.database()
module.exports = {
  _before: function() { // 通用预处理器
    this.startTime = Date.now()
    this.params = this.getParams()
  },
  getMoney: async function() {
    const res = await db.collection("as-user").where({
      role_name: this.params[0]
    }).get()
    const arr = res.data.map(item => {
      return {
        money: item.role_money,
        integral: item.role_integral
      }
    })
    return result(200, "success", arr, res.affectedDocs);
  },
  search: async function() {
    const search = await db.collection("as-user").where({
      role_name: this.params[0],
    }).get()
    if (search.affectedDocs == 0) {
      return result(200, "success", search, search.affectedDocs);
    } else {
      return result(400, "success", search, search.affectedDocs);
    }
  },
  addUser: async function() {
    const res = await db.collection("as-user").add({
      "role_id": 'wx:' + Math.floor(Math.random() * 1000) + Math.floor(Math.random() * 10000000000),
      "role_mobile": 15517630000,
      "role_name": this.params[0].role_name,
      "role_money": 0
    })
    return result(200, "success", res, res.affectedDocs);
  },
  updateUser: async function() {
    const update = await db.collection("as-user").where({
      role_name: this.params[0].old,
    }).update({
      role_name: this.params[0].new,
    })
    return result(200, "success", update, update.affectedDocs);
  },
  updateUserNumber: async function() {
    const update = await db.collection("as-user").where({
      role_name: this.params[0].name,
    }).update({
      role_name: this.params[0].telNumber,
    })
    return result(200, "success", update, update.affectedDocs);
  },
  _after: function(error, result) {
    if (error) {
      throw error
    }
    result.timeCost = Date.now() - this.startTime
    return result
  }
}
