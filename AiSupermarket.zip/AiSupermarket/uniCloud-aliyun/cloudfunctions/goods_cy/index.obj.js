const {
  result
} = require("goods-utils");
const db = uniCloud.database()
module.exports = {
  _before: function() { // 通用预处理器
    this.startTime = Date.now()
    // let body = this.getHttpInfo().body; //获取传参数值
    // if (!body) throw result(400, "required")
    this.params = this.getParams()
    if (!this.params) throw result(400, "required")
    // this.params = JSON.parse(this.getHttpInfo().body) //
  },
  // 获取所有商品类别
  getCategory: async function() {
    const res = await db.collection("goods-categories").where({}).get()
    const arr = res.data.map(item => {
      return {
        category_name: item.name,
      }
    })
    return result(200, "success", arr, res.affectedDocs);
  },

  // 获取同一类的商品信息
  getCategoryList: async function() {
    let res1 = await db.collection("as-goods").where({
      "category_id": this.params[0].category_id
    }).count()
    let res = await db.collection("as-goods").where({
      "category_id": this.params[0].category_id
    }).skip((this.params[0].pagenum - 1) * 8).limit(8).get()
    if (!res.affectedDocs) {
      res = await db.collection("as-goods").where({
        name: new RegExp(this.params)
      }).get()
    }
    if (!res.affectedDocs) {
      res = await db.collection("as-goods").where({
        is_hot: true
      }).get()
    }
    const arr = res.data.map(item => {
      return {
        goods_price: item.goods_price,
        name: item.name,
        goods_url: item.goods_url.url,
        goods_sn: item.goods_sn
      }
    })
    return result(200, "success", arr, res1.total);
  },
  //获取商品详细信息
  getGoodsDetails: async function() {
    let res = await db.collection("as-goods").where({
      "goods_sn": this.params[0],
    }).get()
    if (res.affectedDocs == 0) {
      let res1 = await db.collection("limit-goods").where({
        "goods_sn": this.params[0],
      }).get()
      res = res1
    }
    const arr = res.data.map(item => {
      return {
        goods_price: item.goods_price,
        name: item.name,
        goods_url: item.goods_url.url,
        goods_sn: item.goods_sn,
        remainCount: item.remain_count,
        category_id: item.category_id,
        goods_date: item.goods_date,
        expiration_date: item.expiration_date,
        goods_location: item.goods_location
      }
    })
    return result(200, "success", arr, res.affectedDocs);
  },

  _after: function(error, result) {
    if (error) {
      throw error
    }
    result.timeCost = Date.now() - this.startTime
    return result
  }
}
