const {
  result
} = require("goods-utils");
const db = uniCloud.database()
module.exports = {
  _before: function() { // 通用预处理器
    this.startTime = Date.now()
    // let body = this.getHttpInfo().body; //获取传参数值
    // if (!body) throw result(400, "required")
    // this.params = JSON.parse(this.getHttpInfo().body) //
  },
  getHot: async function() {
    const res = await db.collection("as-goods").where({
      "is_hot": true,
      is_on_sale: true
    }).limit(7).get()
    const arr = res.data.map(item => {
      return {
        goods_price: item.goods_price,
        name: item.name,
        goods_url: item.goods_url.url,
        goods_sn: item.goods_sn
      }
    })
    return result(200, "success", arr, res.affectedDocs);
  },
  getNew: async function() {
    const res = await db.collection("as-goods").where({
      "is_new": true,
      is_on_sale: true
    }).limit(7).get()
    const arr = res.data.map(item => {
      return {
        goods_price: item.goods_price,
        name: item.name,
        goods_url: item.goods_url.url,
        goods_sn: item.goods_sn
      }
    })
    return result(200, "success", arr, res.affectedDocs);
  },
  getBest: async function() {
    const res = await db.collection("as-goods").where({
      "is_best": true,
      is_on_sale: true
    }).limit(7).get()
    const arr = res.data.map(item => {
      return {
        goods_price: item.goods_price,
        name: item.name,
        goods_url: item.goods_url.url,
        goods_sn: item.goods_sn
      }
    })
    return result(200, "success", arr, res.affectedDocs);
  },
  _after: function(error, result) {
    if (error) {
      throw error
    }
    result.timeCost = Date.now() - this.startTime
    return result
  }
}
