/**
 * 数据库操作
 */
module.exports = {
	uniIdUsers: require('./uniIdUsers'),
	uniPayOrders: require('./uniPayOrders'),
	uniStatPayResult: require('./uniStatPayResult'),
	uniStatSessionLogs: require('./uniStatSessionLogs'),
	uniStatUserSessionLogs: require('./uniStatUserSessionLogs'),
}
