function giveMsg(str) {
  const msg = {
    "success": "查询成功",
    "failure": "查询失败",
    "required": "缺少参数",
  }
  return msg[str]
}

function giveCode(num) {
  const code = {
    200: 200, //成功调用代码
    400: 400, //调用失败代码
    300: 300, //商品不足
  }
  return code[num]
}

function result(errcode, errMsg, data, total) {
  return {
    errcode: giveCode(errcode),
    errMsg: giveMsg(errMsg),
    data,
    total
  }
}
module.exports = {
  giveCode,
  giveMsg,
  result
}
